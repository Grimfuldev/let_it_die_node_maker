from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
from typing import Dict, List, Optional, Tuple, Any

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True

from map_core import *  # Node, MapState, AssetStore, MapRenderer, constants, helpers



UPDATE_API = "https://api.github.com/repos/Grimfuldev/let_it_die_node_maker/releases/latest"
UPDATE_BAT = "update_swap.bat"
UPDATE_FLAG = "update_result.txt"


def _ver_tuple(text: str):
    parts = []
    for piece in str(text or "").lower().lstrip("v").split("."):
        num = ""
        for ch in piece:
            if ch.isdigit():
                num += ch
            else:
                break
        parts.append(int(num or 0))
    return tuple(parts)


def consume_update_flag() -> str:
    flag = os.path.join(SCRIPT_DIR, UPDATE_FLAG)
    bat = os.path.join(SCRIPT_DIR, UPDATE_BAT)
    msg = ""
    if os.path.isfile(flag):
        try:
            raw = open(flag, encoding="utf-8").read().strip().lower()
        except OSError:
            raw = ""
        msg = "Update successful" if raw == "ok" else "Program failed to update"
        try:
            os.remove(flag)
        except OSError:
            pass
    if os.path.isfile(bat):
        try:
            os.remove(bat)
        except OSError:
            pass
    return msg


def _latest_release():
    import json
    import urllib.request
    req = urllib.request.Request(UPDATE_API, headers={"User-Agent": "LetItDieNodeMaker"})
    with urllib.request.urlopen(req, timeout=12) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    tag = str(data.get("tag_name") or "")
    url = ""
    for asset in data.get("assets") or []:
        if str(asset.get("name") or "").lower() == "letitdie_nodemaker.exe":
            url = str(asset.get("browser_download_url") or "")
            break
    return tag, url


def run_editor():
    import pygame
    from pygame import Rect

    pygame.init()
    pygame.key.set_repeat(350, 35)
    shortcuts = load_shortcuts()
    hotkey_held = set()
    pygame.display.set_caption(WINDOW_TITLE)
    screen = pygame.display.set_mode((1600, 900), pygame.RESIZABLE)
    apply_editor_chrome(screen)
    clock = pygame.time.Clock()
    def pg_font(path, size, bold=False):
        if path:
            try:
                return pygame.font.Font(path, size)
            except Exception:
                pass
        f = pygame.font.SysFont("arial,segoeui,tahoma,calibri,sans", size, bold=bold)
        return f

    ui_font = pg_font(FONT_PATH, 13)
    ui_font_sm = pg_font(FONT_PATH, 11)
    ui_font_b = pg_font(FONT_BOLD, 13, bold=True)

    ensure_user_asset_folders()
    assets = AssetStore()
    assets.load_json(DEFAULT_JSON)
    renderer = MapRenderer(assets)
    state = MapState()
    boot = placeholder_json_path()
    if boot:
        try:
            with open(boot, "r", encoding="utf-8") as f:
                state.load_dict(json.load(f), assets)
        except Exception:
            state.seed_default()
    else:
        state.seed_default()
    def saved_map_fingerprint() -> str:
        return json.dumps(enrich_groups(state, assets), sort_keys=True, separators=(",", ":"))

    last_saved_sig = saved_map_fingerprint()

    def start_update():
        nonlocal last_saved_sig
        if saved_map_fingerprint() != last_saved_sig:
            if native_yes_no("Let It Die Node Maker", "Save changes before updating?"):
                state.name = fields["export_name"] or "Placeholder"
                path = native_file_dialog(
                    "save", "Export map JSON",
                    [("JSON", "*.json"), ("All files", "*.*")],
                    SCRIPT_DIR, f"{state.name}.json",
                )
                if not path:
                    return
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(state.to_dict(), f, indent=2)
                last_saved_sig = saved_map_fingerprint()
        if not getattr(sys, "frozen", False):
            try:
                tag, url = _latest_release()
            except Exception:
                set_status("No internet to check for updates")
                return
            if tag and _ver_tuple(tag) <= _ver_tuple(VERSION):
                set_status("Program is up to date")
            else:
                set_status("Program failed to update")
            return
        exe = os.path.abspath(sys.argv[0])
        try:
            tag, url = _latest_release()
        except Exception:
            set_status("No internet to check for updates")
            return
        if not tag or not url:
            set_status("Program failed to update")
            return
        if _ver_tuple(tag) <= _ver_tuple(VERSION):
            set_status("Program is up to date")
            return
        bat = os.path.join(SCRIPT_DIR, UPDATE_BAT)
        flag = os.path.join(SCRIPT_DIR, UPDATE_FLAG)
        new_exe = os.path.join(SCRIPT_DIR, "LetItDie_NodeMaker.new.exe")
        lines = [
            "@echo off",
            "setlocal",
            'set "EXE=' + exe + '"',
            'set "URL=' + url + '"',
            'set "NEW=' + new_exe + '"',
            'set "FLAG=' + flag + '"',
            "timeout /t 2 /nobreak >nul",
            'powershell -NoProfile -Command "try { Invoke-WebRequest -Uri $env:URL -OutFile $env:NEW -UseBasicParsing; exit 0 } catch { exit 1 }"',
            "if errorlevel 1 (",
            '  echo failed>"%FLAG%"',
            '  del "%NEW%" 2>nul',
            '  start "" "%EXE%"',
            '  del "%~f0"',
            "  exit /b 1",
            ")",
            'move /y "%NEW%" "%EXE%" >nul',
            "if errorlevel 1 (",
            '  echo failed>"%FLAG%"',
            '  del "%NEW%" 2>nul',
            '  start "" "%EXE%"',
            '  del "%~f0"',
            "  exit /b 1",
            ")",
            'echo ok>"%FLAG%"',
            'start "" "%EXE%"',
            'del "%~f0"',
            "",
        ]
        try:
            with open(bat, "w", encoding="utf-8", newline="") as f:
                f.write("\r\n".join(lines))
            subprocess.Popen(["cmd", "/c", "start", "", bat], cwd=SCRIPT_DIR, close_fds=True)
        except OSError:
            set_status("Program failed to update")
            return
        pygame.quit()
        raise SystemExit(0)


    # camera
    cam_x, cam_y = 0, 0
    zoom = 0.55
    dragging_map = False
    dragging_scroll = False
    search_open = False
    connect_press = None
    last_mouse = (0, 0)

    selected_node: Optional[str] = None
    selected_sticker: Optional[str] = None
    dragging_node = None
    dragging_sticker = None
    dragging_elev = None
    drag_grab_off = 0  # px from node left where click started
    drag_sticker_off = (0, 0)
    awaiting_resume_off = None  # after teleport, wait for mouse local x
    last_dir = 0
    stickers_dragged_with: List[Tuple[str, int, int]] = []  # id, dx_tiles, dy_tiles

    status = consume_update_flag() or "Ready."
    status_at = 0
    collapsed_cats = set()
    status_color = (200, 200, 160)
    lock_stickers = False
    hide_stickers = False
    flip_bg = False
    hide_paths = False
    hide_mode = 0
    last_dot_click = {"id": "", "t": 0}
    path_v_used = False
    catalog_rmb = None
    show_floor_ruler = False
    floor_box_surf = None
    catalog_sel = 0
    pg_thumbs: Dict[str, Any] = {}
    thumb_cd_until = 0
    view_cache = {"sig": None, "surf": None, "box": (0, 0, 1, 1)}
    panel_bg_cache = {"key": None, "surf": None}
    catalog_scroll = 0
    catalog_dragging = False
    catalog_bar = {"rect": None, "max": 0}
    focused_port: Optional[str] = None
    port_focus_at = 0

    def set_focused_port(pk: Optional[str]):
        nonlocal focused_port, port_focus_at
        if pk != focused_port:
            port_focus_at = pygame.time.get_ticks()
        focused_port = pk

    def do_export_json():
        nonlocal last_saved_sig
        state.name = fields["export_name"] or "Placeholder"
        path = native_file_dialog("save", "Export map JSON",
                                 [("JSON", "*.json"), ("All files", "*.*")],
                                 SCRIPT_DIR, f"{state.name}.json")
        if path:
            state.ui = snapshot_ui(lock_stickers, hide_mode, show_floor_ruler, flip_bg,
                                   getattr(assets, "starred_folders", set()), collapsed_cats)
            data = enrich_groups(state, assets)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            last_saved_sig = saved_map_fingerprint()
            set_status(f"Exported {path}")

    def do_render_png():
        broken = [n.title for n in state.nodes if node_is_invalid(n, state)]
        state.name = fields["export_name"] or "Placeholder"
        folder = native_file_dialog("dir", "Choose folder for rendered image", initialdir=SCRIPT_DIR)
        if not folder:
            return
        out = os.path.join(folder, f"{state.name}.webp")
        tmp = os.path.join(tempfile.gettempdir(), "lid_render_job.json")
        state.ui = snapshot_ui(lock_stickers, hide_mode, show_floor_ruler, flip_bg,
                               getattr(assets, "starred_folders", set()), collapsed_cats)
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(enrich_groups(state, assets), f)
        helper = os.path.join(bundle_dir(), "render_popup.py")
        if not os.path.isfile(helper):
            helper = os.path.join(SCRIPT_DIR, "render_popup.py")
        args = [sys.executable]
        if getattr(sys, "frozen", False):
            args = [sys.executable, "--render-popup"]
        else:
            args = [sys.executable, helper]
        args += ["--json", tmp, "--out", out]
        if hide_stickers:
            args.append("--hide-stickers")
        if hide_paths:
            args.append("--hide-paths")
        if flip_bg:
            args.append("--flip-bg")
        try:
            proc = subprocess.Popen(args, cwd=SCRIPT_DIR)
            while proc.poll() is None:
                pygame.event.clear()
                pygame.event.pump()
                clock.tick(30)
            if proc.returncode == 0:
                if broken:
                    set_status("Some nodes are not connected")
                else:
                    set_status(f"Rendered {out}")
            elif proc.returncode == 2:
                set_status("Render cancelled.")
            else:
                set_status("Render failed.")
        except Exception as e:
            set_status(f"Render popup failed: {e}")

    connect_mode: Optional[str] = None  # None | pick_node | pick_port
    connect_src_id: Optional[str] = None
    connect_src_port: Optional[str] = None
    connect_dest_id: Optional[str] = None

    # text fields
    fields = {
        "export_name": state.name,
        "title": "",
        "floor": "",
        "stars": "",
        "sticker_x": str(blue_elevator_x()),
        "sticker_y": "390",
        "sticker_level": "",
        "sticker_amount": "",
        "base": "0",
        "search": "",
    }
    active_field = None
    field_backup = {}
    field_sel = {}  # key -> (start, end) inclusive-exclusive
    field_view = {}  # key -> first visible char
    selecting_field = None
    caret_blink = 0

    port_color = {k: "cyan" for k in PORT_KEYS}
    port_gate = {k: "none" for k in PORT_KEYS}
    mat_sel = "Empty"
    elev_sel = "none"
    roof_sel = False
    mat_right_sel = False
    tengoku_sel = False
    jigoku_sel = False

    def set_status(msg: str):
        nonlocal status, status_color, status_at
        status = msg
        status_at = pygame.time.get_ticks()
        low = (msg or "").lower()
        if low.startswith("refused") or low.startswith("refuse"):
            status_color = (255, 150, 150)
        else:
            status_color = (200, 200, 160)

    def despawn_selected_node():
        nonlocal selected_node, selected_sticker
        if not selected_node:
            return
        nd = state.find_by_id(selected_node)
        old_fc = state.floor_count()
        drop = set()
        if nd:
            title = nd.title.strip().lower()
            for pk in list(nd.ports.keys()):
                clear_port_link(nd, pk, state)
            for o in state.nodes:
                if o.id == nd.id:
                    continue
                for pk, pdata in o.ports.items():
                    if (pdata.get("target") or "").strip().lower() == title:
                        pdata["target"] = ""
            fc = state.floor_count()
            for st in state.stickers:
                if sticker_hits_node(st, nd, assets, fc, min_floor=state.min_floor()):
                    drop.add(st.id)
        state.nodes = [n for n in state.nodes if n.id != selected_node]
        if drop:
            for sid in drop:
                unregister_path_dot(state, sid)
            state.stickers = [s for s in state.stickers if s.id not in drop]
        selected_node = None
        selected_sticker = None
        adjust_stickers_after_floor_change(state, assets, old_fc)
        prune_edge_ports(state)
        set_status("Node deleted.")

    def fill_form_from_node(n: Optional[Node]):
        nonlocal mat_sel, elev_sel, roof_sel, mat_right_sel, tengoku_sel, jigoku_sel, focused_port, active_field, selecting_field
        if active_field:
            commit_field(active_field)
            active_field = None
            selecting_field = None
        if n is None:
            fields["title"] = ""
            fields["floor"] = ""
            fields["stars"] = ""
            tengoku_sel = False
            jigoku_sel = False
            for k in PORT_KEYS:
                port_color[k] = "cyan"
                port_gate[k] = "none"
            mat_sel = "Empty"
            elev_sel = "none"
            roof_sel = False
            mat_right_sel = False
            set_focused_port(None)
            return
        fields["title"] = n.title
        fields["floor"] = str(n.floor)
        fields["stars"] = n.stars
        ny = node_y_on_floor(n.floor, state.floor_count(), state.min_floor())
        fields["sticker_x"] = str(int(round(n.x + NODE_W / 2)))
        fields["sticker_y"] = str(int(round(ny + NODE_H / 2)))
        mat_sel = n.material
        elev_sel = n.elevator
        roof_sel = bool(getattr(n, "roof", False))
        mat_right_sel = bool(getattr(n, "mat_right", False))
        tengoku_sel = bool(getattr(n, "tengoku", False))
        jigoku_sel = bool(getattr(n, "jigoku", False))
        for k in PORT_KEYS:
            port_color[k] = n.ports[k].get("color", "cyan")
            port_gate[k] = n.ports[k].get("gate", "none")
        set_focused_port(None)

    fill_form_from_node(None)

    def read_form_into(n: Node):
        nonlocal tengoku_sel, jigoku_sel
        # Snapshot decorations on this node BEFORE any x/floor/elevator snap.
        carried = collect_node_stickers(n, state, assets, state.floor_count())
        new_title = fields["title"].strip() or n.title
        other = state.find_by_title(new_title)
        if other is not None and other.id != n.id:
            set_status("REFUSED: that node name already exists")
            return False
        old_title = n.title
        n.title = new_title
        if old_title.strip().lower() != new_title.strip().lower() or old_title != new_title:
            retarget_node_title(state, old_title, new_title)
        n.stars = fields["stars"].strip()
        n.material = mat_sel
        n.mat_right = bool(mat_right_sel)
        try:
            parsed = parse_floor_text(fields["floor"])
            new_fl = n.floor if parsed is None else parsed
        except ValueError:
            new_fl = n.floor
        new_elev = elev_sel
        old_elev = n.elevator
        old_grp = list(state.elevator_segment(n)) if old_elev not in ("", "none") else [n]
        dest_rig = []
        if new_elev not in ("", "none"):
            others = [g for g in state.elevator_group(new_elev) if g.id != n.id]
            if others:
                near = min(others, key=lambda g: abs(g.floor - new_fl))
                dest_rig = [g for g in state.elevator_segment(near) if g.id != n.id]

        if new_elev in ("", "none"):
            targets = [n]
            new_elev = "none"
        elif dest_rig:
            targets = [n]
        else:
            targets = list(old_grp) if old_elev not in ("", "none") else [n]

        for g in targets:
            fl = new_fl if g.id == n.id else g.floor
            if new_elev not in ("", "none") and elevator_on_floor(state, new_elev, fl, g.id):
                set_status(f"REFUSED: {new_elev} elevator already on {floor_label(fl)}")
                return False
        if new_elev not in ("", "none"):
            probe = Node(id=n.id, title=n.title, floor=new_fl, x=n.x, elevator=new_elev)
            if fit_x_on_floor(probe, n.x, new_fl, state) is None:
                set_status(f"REFUSED: no space for {new_elev} elevator on {floor_label(new_fl)}")
                return False
        for g in targets:
            g.elevator = new_elev
            g.elevator_a = ""
            g.elevator_b = ""
        n.roof = bool(roof_sel)
        for k in PORT_KEYS:
            n.ports[k]["color"] = port_color[k]
            n.ports[k]["gate"] = port_gate[k]
        blocked = move_node_to_floor(n, new_fl, state, assets)
        if blocked:
            fields["floor"] = str(n.floor)
            set_status(blocked)
            return False
        if n.elevator != "none":
            apply_elevator_x(state, n.elevator, n.x, assets, anchor=n)
        # Re-attach the original snapshot at the final x/floor.
        apply_node_stickers(n, carried, state, state.floor_count())
        err_z = apply_zone_flag(state, n, "tengoku", bool(tengoku_sel))
        if err_z:
            tengoku_sel = bool(getattr(n, "tengoku", False))
            set_status(err_z)
            prune_edge_ports(state)
            return False
        err_z = apply_zone_flag(state, n, "jigoku", bool(jigoku_sel))
        if err_z:
            jigoku_sel = bool(getattr(n, "jigoku", False))
            set_status(err_z)
            prune_edge_ports(state)
            return False
        prune_edge_ports(state)
        return True

    def add_sticker_from_ui():
        nonlocal selected_sticker, selected_node
        names = assets.sticker_names
        if not names:
            set_status("No stickers in Sticker_assets")
            return
        name = names[catalog_sel % len(names)]
        try:
            tx = int(fields["sticker_x"] or "0")
            ty = int(fields["sticker_y"] or "0")
        except ValueError:
            tx, ty = 0, 0
        if assets.get(name) is None:
            set_status(f"Missing image for sticker '{name}'")
            return
        tx, ty = clamp_sticker_xy(tx, ty, state, assets, name, False)
        cur = next((s for s in state.stickers if s.id == selected_sticker), None) if selected_sticker else None
        if cur is not None and cur.name == name:
            cur.level = badge_text(fields.get("sticker_level"))
            cur.amount = badge_text(fields.get("sticker_amount"))
            fields["sticker_level"] = cur.level
            fields["sticker_amount"] = cur.amount
            set_status(f"Updated {name} badges")
            return
        if any(s.name == name and s.tile_x == tx and s.tile_y == ty for s in state.stickers):
            set_status("REFUSED: same sticker already at that position")
            return
        st = Sticker(id=state.next_id("s"), name=name, tile_x=tx, tile_y=ty, big=False,
                     level=badge_text(fields.get("sticker_level")),
                     amount=badge_text(fields.get("sticker_amount")))
        state.stickers.append(st)
        register_path_dot(state, st, selected_sticker)
        selected_sticker = st.id
        selected_node = None
        set_status(f"Added sticker {name} @ ({tx},{ty})")

    def despawn_selected_sticker():
        nonlocal selected_sticker, selected_node
        if not selected_sticker:
            set_status("No sticker selected.")
            return
        st = next((s for s in state.stickers if s.id == selected_sticker), None)
        nxt_id = None
        color = path_dot_color(st.name) if st else ""
        if color:
            ids = list(((state.path_routes or {}).get(color) or {}).get("ids") or [])
            if selected_sticker in ids:
                i = ids.index(selected_sticker)
                if i + 1 < len(ids):
                    nxt_id = ids[i + 1]
                elif i > 0:
                    nxt_id = ids[i - 1]
        unregister_path_dot(state, selected_sticker)
        state.stickers = [s for s in state.stickers if s.id != selected_sticker]
        selected_sticker = nxt_id
        selected_node = None
        if selected_sticker:
            nxt = next((s for s in state.stickers if s.id == selected_sticker), None)
            if nxt:
                fields["sticker_x"] = str(int(nxt.tile_x))
                fields["sticker_y"] = str(int(nxt.tile_y))
        set_status("Sticker despawned.")

    def cancel_connect(msg="Connection cancelled."):
        nonlocal connect_mode, connect_src_id, connect_src_port, connect_dest_id, connect_press
        connect_mode = None
        connect_src_id = None
        connect_src_port = None
        connect_dest_id = None
        connect_press = None
        set_status(msg)

    def finish_connect_click(sx, sy):
        nonlocal focused_port, selected_node, selected_sticker, connect_dest_id
        wx, wy = world_from_screen(sx, sy, sw, sh)
        src = state.find_by_id(connect_src_id) if connect_src_id else None
        dest = hit_node(wx, wy)
        if dest is None or src is None:
            return
        if dest.id == src.id:
            cancel_connect("Connection cancelled.")
            return
        if not dest_floor_ok(src, connect_src_port, dest):
            cancel_connect("REFUSED: same-floor or up/down mismatch — connection aborted.")
            return
        connect_dest_id = dest.id
        selected_node = dest.id
        selected_sticker = None
        fill_form_from_node(dest)
        set_status("doing port connection — click a valid port (or another node)")

    def canvas_rect(sw, sh):
        return Rect(0, 0, max(8, sw - 420 - SCROLL_W), sh - 28)

    def scroll_rect(sw, sh):
        return Rect(sw - 420 - SCROLL_W, 0, SCROLL_W, sh - 28)

    def scroll_cam_from_y(my, sw, sh):
        nonlocal cam_y
        sr = scroll_rect(sw, sh)
        cr = canvas_rect(sw, sh)
        world_h = state.floor_count() * FLOOR_H
        view_h = cr.h / max(0.05, zoom)
        max_cam = max(0.0, world_h - view_h)
        steps = max(1, int(math.ceil(max_cam / FLOOR_H)))
        t = (my - sr.y) / max(1, sr.h)
        step = int(clamp(round(t * steps), 0, steps))
        cam_y = min(max_cam, step * FLOOR_H)

    def world_from_screen(mx, my, sw, sh):
        r = canvas_rect(sw, sh)
        wx = (mx - r.x) / zoom + cam_x
        wy = (my - r.y) / zoom + cam_y
        return wx, wy

    def hit_node(wx, wy) -> Optional[Node]:
        fc = state.floor_count()
        mf = state.min_floor()
        # topmost first
        for n in reversed(state.nodes):
            ny = node_y_on_floor(n.floor, fc, mf)
            if n.x <= wx <= n.x + NODE_W and ny <= wy <= ny + NODE_H:
                return n
        return None

    def hit_elevator_icon(wx, wy) -> Optional[Node]:
        fc = state.floor_count()
        mf = state.min_floor()
        for n in reversed(state.nodes):
            if not n.elevator or n.elevator == "none":
                continue
            ev = assets.get_elevator(n.elevator)
            w = ev.width if ev is not None else ELEV_S
            h = ev.height if ev is not None else ELEV_S
            ny = node_y_on_floor(n.floor, fc, mf)
            half = w / 2
            dx = clamp(int(getattr(n, "elev_dx", 0)), int(-NODE_W / 2 + half), int(NODE_W / 2 - half))
            ex = n.x + NODE_W / 2 - half + dx
            ey = ny + NODE_H / 2 - h / 2 + 22
            if ex <= wx <= ex + w and ey <= wy <= ey + h:
                return n
        return None

    def hit_sticker(wx, wy) -> Optional[Sticker]:
        for st in reversed(state.stickers):
            img = assets.get(st.name)
            if img is None:
                continue
            x, y = sticker_world(st)
            w, h = sticker_size(st.name, assets, getattr(st, "big", False))
            if x <= wx <= x + w and y <= wy <= y + h:
                if hide_stickers or (hide_paths and path_dot_color(st.name)) or (
                        lock_stickers and sticker_locked_on_node(st, state, assets)):
                    continue
                return st
        return None

    # widget layout helpers
    buttons = {}  # name -> Rect computed each frame

    def draw_text(surf, text, pos, font=None, color=(230, 230, 230)):
        font = font or ui_font
        surf.blit(font.render(text, True, color), pos)

    def button(surf, name, rect, label, mouse, click):
        hover = rect.collidepoint(mouse)
        col = (70, 70, 80) if not hover else (95, 95, 110)
        pygame.draw.rect(surf, col, rect, border_radius=3)
        pygame.draw.rect(surf, (140, 140, 150), rect, 1, border_radius=3)
        ts = ui_font.render(label, True, (240, 240, 240))
        surf.blit(ts, (rect.x + (rect.w - ts.get_width()) // 2, rect.y + (rect.h - ts.get_height()) // 2))
        buttons[name] = rect
        return click and hover

    def _field_slice(key, rect):
        txt = fields.get(key, "")
        max_w = max(8, rect.w - 8)
        sel = field_sel.get(key) or (len(txt), len(txt))
        caret = max(0, min(len(txt), sel[1]))
        off = max(0, min(len(txt), field_view.get(key, 0)))
        if caret < off:
            off = caret
        while off < caret and ui_font.size(txt[off:caret])[0] > max_w:
            off += 1
        end = off
        while end < len(txt) and ui_font.size(txt[off:end + 1])[0] <= max_w:
            end += 1
        field_view[key] = off
        return off, txt[off:end]

    def _field_index_at(key, rect, mx):
        txt = fields.get(key, "")
        off, shown = _field_slice(key, rect)
        x = mx - rect.x - 4
        if x <= 0:
            return off
        for i in range(len(shown) + 1):
            if ui_font.size(shown[:i])[0] >= x:
                return off + i
        return off + len(shown)

    def commit_field(key: str) -> bool:
        nonlocal active_field
        if not key or key not in fields:
            return True
        raw = fields.get(key, "")
        prev = field_backup.get(key, raw)
        ok = True
        if key == "stars":
            fields[key] = "".join(c for c in raw if c.isdigit())
            n = state.find_by_id(selected_node) if selected_node else None
            if n is not None:
                n.stars = fields[key]
        elif key == "floor":
            try:
                v = parse_floor_text(raw)
                if v is None:
                    raise ValueError
                fields[key] = str(v)
            except ValueError:
                fields[key] = prev
                ok = False
                set_status("REFUSED: floor must be an integer (0 = B1, negatives allowed)")
            else:
                n = state.find_by_id(selected_node) if selected_node else None
                if n is not None and not read_form_into(n):
                    fields[key] = prev
                    ok = False
        elif key == "title":
            t = raw.strip()
            n = state.find_by_id(selected_node) if selected_node else None
            if not t:
                if n is not None:
                    fields[key] = prev or n.title
                    ok = False
                else:
                    fields[key] = t
            else:
                other = state.find_by_title(t)
                if other is not None and (n is None or other.id != n.id):
                    fields[key] = prev
                    ok = False
                    set_status("REFUSED: that node name already exists")
                else:
                    fields[key] = t
                    if n is not None and n.title != t:
                        retarget_node_title(state, n.title, t)
                        n.title = t
        elif key in ("sticker_level", "sticker_amount"):
            fields[key] = badge_text(raw)
            st = next((s for s in state.stickers if s.id == selected_sticker), None)
            if st is not None:
                if key == "sticker_level":
                    st.level = fields[key]
                else:
                    st.amount = fields[key]
        elif key in ("sticker_x", "sticker_y"):
            try:
                v = int(str(raw).strip())
                fields[key] = str(v)
            except ValueError:
                fields[key] = prev
                ok = False
                set_status("REFUSED: sticker coordinate must be a number")
            else:
                st = next((s for s in state.stickers if s.id == selected_sticker), None)
                if st is not None:
                    try:
                        tx = int(fields["sticker_x"] or "0")
                        ty = int(fields["sticker_y"] or "0")
                    except ValueError:
                        tx, ty = int(st.tile_x), int(st.tile_y)
                    st.tile_x, st.tile_y = clamp_sticker_xy(tx, ty, state, assets, st.name, st.big)
                    fields["sticker_x"] = str(int(st.tile_x))
                    fields["sticker_y"] = str(int(st.tile_y))
        elif key == "base":
            rawu = (raw or "").strip().upper()
            new_base = None
            if rawu in ("B1", "0"):
                new_base = 0
            else:
                try:
                    new_base = int(rawu)
                except ValueError:
                    new_base = None
            if new_base is None:
                fields[key] = prev
                ok = False
                set_status("REFUSED: base must be an integer (0 / B1 or negative)")
            else:
                fields[key] = "0" if new_base == 0 else str(new_base)
        elif key == "export_name":
            t = raw.strip()
            if not t:
                fields[key] = prev or "Placeholder"
            else:
                fields[key] = t
                state.name = t
        field_backup[key] = fields.get(key, prev)
        return ok

    def field_box(surf, key, rect, mouse, click, label=None):
        nonlocal active_field, selecting_field
        if label:
            draw_text(surf, label, (rect.x, rect.y - 14), ui_font_sm, (180, 180, 180))
        hover = rect.collidepoint(mouse)
        if click and hover:
            if active_field and active_field != key:
                commit_field(active_field)
                active_field = None
            if active_field != key:
                field_backup[key] = fields.get(key, "")
            active_field = key
            selecting_field = key
            idx = _field_index_at(key, rect, mouse[0])
            field_sel[key] = (idx, idx)
        focus = active_field == key
        pygame.draw.rect(surf, (25, 25, 30), rect, border_radius=2)
        pygame.draw.rect(surf, (220, 220, 220) if focus else (90, 90, 100), rect, 1, border_radius=2)
        txt = fields.get(key, "")
        off, shown = _field_slice(key, rect)
        ts = ui_font.render(shown, True, (240, 240, 240))
        sel = field_sel.get(key)
        if focus and sel and sel[0] != sel[1]:
            a, b = sorted(sel)
            a, b = max(0, a - off), max(0, b - off)
            x0s = rect.x + 4 + ui_font.size(shown[:a])[0]
            x1s = rect.x + 4 + ui_font.size(shown[:b])[0]
            pygame.draw.rect(surf, (70, 110, 180), Rect(x0s, rect.y + 3, max(2, x1s - x0s), rect.h - 6))
        prev_clip = surf.get_clip()
        surf.set_clip(rect)
        surf.blit(ts, (rect.x + 4, rect.y + (rect.h - ts.get_height()) // 2))
        surf.set_clip(prev_clip)
        if focus and (caret_blink // 30) % 2 == 0:
            caret_i = sel[1] if sel else len(txt)
            caret_i = max(0, caret_i - off)
            cx = rect.x + 4 + ui_font.size(shown[:caret_i])[0]
            pygame.draw.line(surf, (240, 240, 240), (cx, rect.y + 4), (cx, rect.bottom - 4))
        buttons[f"field_{key}"] = rect

    def radio_row(surf, x, y, options, current, mouse, click, prefix):
        chosen = current
        xx = x
        for opt in options:
            r = Rect(xx, y, 8 + ui_font_sm.size(opt)[0] + 16, 18)
            on = current == opt
            pygame.draw.rect(surf, (50, 90, 50) if on else (40, 40, 48), r, border_radius=3)
            pygame.draw.rect(surf, (180, 220, 180) if on else (80, 80, 90), r, 1, border_radius=3)
            surf.blit(ui_font_sm.render(opt, True, (230, 230, 230)), (r.x + 6, r.y + 2))
            if click and r.collidepoint(mouse):
                chosen = opt
            xx = r.right + 4
        return chosen, xx, y + 22

    def checkbox(surf, rect, on, label, mouse, click):
        pygame.draw.rect(surf, (60, 140, 60) if on else (40, 40, 48), rect, border_radius=2)
        pygame.draw.rect(surf, (200, 200, 200), rect, 1, border_radius=2)
        if on:
            pygame.draw.line(surf, (240, 240, 240), (rect.x + 3, rect.y + 8), (rect.x + 7, rect.y + 13), 2)
            pygame.draw.line(surf, (240, 240, 240), (rect.x + 7, rect.y + 13), (rect.x + 14, rect.y + 3), 2)
        surf.blit(ui_font_sm.render(label, True, (220, 220, 220)), (rect.right + 6, rect.y + 1))
        return on if not (click and rect.collidepoint(mouse)) else (not on)

    def draw_gate_lock(surf, x, y, kind: str):
        """Tiny lock so we don't depend on emoji fonts."""
        if kind == "open":
            return
        body = Rect(x + 3, y + 8, 12, 10)
        if kind == "closed-gate":
            col, shackle = (110, 35, 35), (90, 25, 25)
        else:
            col, shackle = (45, 100, 55), (35, 80, 45)
        pygame.draw.arc(surf, shackle, Rect(x + 4, y + 1, 10, 10), 0.0, 3.15, 2)
        pygame.draw.rect(surf, col, body, border_radius=2)

    running = True
    click = False
    while running:
        sw, sh = screen.get_size()
        mouse = pygame.mouse.get_pos()
        click = False
        events = pygame.event.get()
        for ev in events:
            if ev.type == pygame.QUIT:
                if saved_map_fingerprint() != last_saved_sig:
                    if native_yes_no("Let It Die Node Maker",
                                    "Save changes before leaving?"):
                        state.name = fields["export_name"] or "Placeholder"
                        path = native_file_dialog(
                            "save", "Export map JSON",
                            [("JSON", "*.json"), ("All files", "*.*")],
                            SCRIPT_DIR, f"{state.name}.json",
                        )
                        if not path:
                            continue
                        with open(path, "w", encoding="utf-8") as f:
                            json.dump(enrich_groups(state, assets), f, indent=2)
                running = False
            elif ev.type == pygame.VIDEORESIZE:
                screen = pygame.display.set_mode(ev.size, pygame.RESIZABLE)
                pygame.display.set_caption(WINDOW_TITLE)
                apply_editor_chrome(screen)
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if ev.button == 1:
                    click = True
                    last_mouse = ev.pos
                    cr = canvas_rect(sw, sh)
                    sr = scroll_rect(sw, sh)
                    if sr.collidepoint(ev.pos):
                        dragging_scroll = True
                        scroll_cam_from_y(ev.pos[1], sw, sh)
                    elif search_open and Rect(cr.right - 228, cr.y + 6, 226, 22).collidepoint(ev.pos):
                        sbox = Rect(cr.right - 228, cr.y + 6, 200, 22)
                        xbtn = Rect(sbox.right + 4, sbox.y, 22, 22)
                        if xbtn.collidepoint(ev.pos):
                            search_open = False
                            fields["search"] = ""
                            if active_field == "search":
                                active_field = None
                    elif cr.collidepoint(ev.pos) and ev.pos[0] < sw - 420:
                        wx, wy = world_from_screen(*ev.pos, sw, sh)
                        if connect_mode:
                            connect_press = ev.pos
                            last_mouse = ev.pos
                        else:
                            st = hit_sticker(wx, wy)
                            nd = hit_node(wx, wy)
                            if st is not None:
                                add_key = shortcuts.get("add_sticker")
                                prev_st = next((s for s in state.stickers if s.id == selected_sticker), None) if selected_sticker else None
                                if (add_key and add_key in hotkey_held
                                        and prev_st is not None
                                        and path_dot_color(prev_st.name)
                                        and path_dot_color(st.name)):
                                    mid = insert_path_dot_between(state, assets, prev_st, st)
                                    if mid is not None:
                                        path_v_used = True
                                        selected_sticker = mid.id
                                        selected_node = None
                                        fields["sticker_x"] = str(int(mid.tile_x))
                                        fields["sticker_y"] = str(int(mid.tile_y))
                                        set_status(f"Inserted {mid.name} path dot")
                                        fill_form_from_node(None)
                                        continue
                                selected_sticker = st.id
                                selected_node = None
                                sx, sy = sticker_world(st)
                                fields["sticker_x"] = str(int(sx))
                                fields["sticker_y"] = str(int(sy))
                                fields["sticker_level"] = badge_text(getattr(st, "level", ""))
                                fields["sticker_amount"] = badge_text(getattr(st, "amount", ""))
                                if st.name in assets.sticker_names:
                                    catalog_sel = assets.sticker_names.index(st.name)
                                rows = catalog_rows(
                                    getattr(assets, "catalog_entries", None)
                                    or [("item", n) for n in assets.sticker_names], 5)
                                for i, (kind, payload) in enumerate(rows):
                                    if kind == "items" and st.name in payload:
                                        catalog_scroll = i
                                        break
                                nowc = pygame.time.get_ticks()
                                color = path_dot_color(st.name)
                                if (color and last_dot_click["id"] == st.id
                                        and nowc - last_dot_click["t"] < 400):
                                    bucket = state.path_routes.setdefault(color, {"ids": [], "dir": 1})
                                    bucket["dir"] = -1 if int(bucket.get("dir", 1) or 1) >= 0 else 1
                                    last_dot_click = {"id": "", "t": 0}
                                    set_status(f"{color} path arrows flipped")
                                else:
                                    last_dot_click = {"id": st.id, "t": nowc}
                                    dragging_sticker = st.id
                                    drag_sticker_off = (wx - sx, wy - sy)
                                fill_form_from_node(None)
                            else:
                                evn = hit_elevator_icon(wx, wy)
                                if evn is not None:
                                    selected_node = evn.id
                                    selected_sticker = None
                                    fill_form_from_node(evn)
                                    if not (lock_stickers or hide_stickers):
                                        dragging_elev = evn.id
                                elif nd is not None:
                                    join_key = shortcuts.get("join_elevator")
                                    shift_on = bool(pygame.key.get_mods() & pygame.KMOD_SHIFT)
                                    prev = state.find_by_id(selected_node) if selected_node else None
                                    if (shortcuts and join_key and shift_on and prev is not None
                                            and prev.elevator not in ("", "none")
                                            and nd.id != prev.id):
                                        selected_node = nd.id
                                        selected_sticker = None
                                        fields["sticker_level"] = ""
                                        fields["sticker_amount"] = ""
                                        fill_form_from_node(nd)
                                        elev_sel = prev.elevator
                                        if read_form_into(nd):
                                            set_status(f"{nd.title} set to {nd.elevator} elevator")
                                        else:
                                            fill_form_from_node(nd)
                                    else:
                                        selected_node = nd.id
                                        selected_sticker = None
                                        fields["sticker_level"] = ""
                                        fields["sticker_amount"] = ""
                                        fill_form_from_node(nd)
                                        dragging_node = nd.id
                                        drag_grab_off = wx - nd.x
                                        awaiting_resume_off = None
                                        last_dir = 0
                                        stickers_dragged_with = collect_node_stickers(nd, state, assets, state.floor_count())
                                else:
                                    selected_node = None
                                    selected_sticker = None
                                    fields["sticker_level"] = ""
                                    fields["sticker_amount"] = ""
                                    dragging_map = True
                                    fill_form_from_node(None)
                    else:
                        # clicking panel: if not on a field, clear focus later via field_box
                        pass
                elif ev.button == 2:
                    dragging_map = True
                    last_mouse = ev.pos
                elif ev.button == 3:
                    cr = canvas_rect(sw, sh)
                    if cr.collidepoint(ev.pos) and ev.pos[0] < sw - 420:
                        wx, wy = world_from_screen(*ev.pos, sw, sh)
                        st = hit_sticker(wx, wy)
                        if st is not None:
                            unregister_path_dot(state, st.id)
                            state.stickers = [s for s in state.stickers if s.id != st.id]
                            if selected_sticker == st.id:
                                selected_sticker = None
                            set_status("Sticker despawned.")
                        else:
                            fields["sticker_x"] = str(int(wx))
                            fields["sticker_y"] = str(int(wy))
                            if not selected_node:
                                fc = state.floor_count()
                                mf = state.min_floor()
                                idx = int(wy // FLOOR_H)
                                fi = (fc - 1) - idx
                                if 0 <= fi < fc:
                                    fields["floor"] = str(mf + fi)
                            set_status(f"Sticker pos ({int(wx)}, {int(wy)})")
                    elif ev.pos[0] >= sw - 420:
                        catalog_rmb = {"t": pygame.time.get_ticks(), "cleared": False}
                    else:
                        dragging_map = True
                        last_mouse = ev.pos
                elif ev.button == 4:
                    if mouse[0] >= sw - 420:
                        catalog_scroll = max(0, catalog_scroll - 1)
                    else:
                        zoom = clamp(zoom * 1.1, 0.2, 2.0)
                elif ev.button == 5:
                    if mouse[0] >= sw - 420:
                        catalog_scroll += 1
                    else:
                        zoom = clamp(zoom / 1.1, 0.2, 2.0)
            elif ev.type == pygame.MOUSEBUTTONUP:
                if connect_mode and connect_press and not dragging_map and ev.button == 1:
                    finish_connect_click(*connect_press)
                connect_press = None
                dragging_map = False
                dragging_scroll = False
                dragging_node = None
                dragging_sticker = None
                dragging_elev = None
                awaiting_resume_off = None
                stickers_dragged_with = []
                selecting_field = None
                catalog_dragging = False
                catalog_rmb = None
            elif ev.type == pygame.MOUSEMOTION:
                mx, my = ev.pos
                if catalog_dragging and catalog_bar.get("rect"):
                    r = catalog_bar["rect"]
                    max_s = catalog_bar.get("max", 0)
                    t = (my - r.y) / max(1, r.h)
                    catalog_scroll = int(clamp(t * (max_s + 1), 0, max_s))
                elif selecting_field and selecting_field in fields:
                    rsel = buttons.get(f"field_{selecting_field}")
                    if rsel:
                        idx = _field_index_at(selecting_field, rsel, mx)
                        a = field_sel.get(selecting_field, (idx, idx))[0]
                        field_sel[selecting_field] = (a, idx)
                elif connect_mode and connect_press and ev.buttons[0]:
                    if abs(mx - connect_press[0]) + abs(my - connect_press[1]) > 8:
                        dragging_map = True
                    if dragging_map:
                        dx = (last_mouse[0] - mx) / zoom
                        dy = (last_mouse[1] - my) / zoom
                        cam_x += dx
                        cam_y += dy
                        last_mouse = ev.pos
                elif dragging_scroll:
                    scroll_cam_from_y(my, sw, sh)
                    last_mouse = ev.pos
                elif dragging_map:
                    dx = (last_mouse[0] - mx) / zoom
                    dy = (last_mouse[1] - my) / zoom
                    cam_x += dx
                    cam_y += dy
                    last_mouse = ev.pos
                elif dragging_elev:
                    wx, wy = world_from_screen(mx, my, sw, sh)
                    n = state.find_by_id(dragging_elev)
                    if n:
                        ev = assets.get_elevator(n.elevator)
                        w = ev.width if ev is not None else ELEV_S
                        half = w / 2
                        dx = wx - (n.x + NODE_W / 2)
                        n.elev_dx = int(clamp(dx, -NODE_W / 2 + half, NODE_W / 2 - half))
                elif dragging_sticker:
                    wx, wy = world_from_screen(mx, my, sw, sh)
                    for st in state.stickers:
                        if st.id == dragging_sticker:
                            st.tile_x, st.tile_y = clamp_sticker_xy(
                                int(wx - drag_sticker_off[0]),
                                int(wy - drag_sticker_off[1]),
                                state, assets, st.name, getattr(st, "big", False))
                            fields["sticker_x"] = str(st.tile_x)
                            fields["sticker_y"] = str(st.tile_y)
                            break
                elif dragging_node:
                    wx, wy = world_from_screen(mx, my, sw, sh)
                    n = state.find_by_id(dragging_node)
                    if n:
                        desired = snap(wx - drag_grab_off)
                        direction = 1 if desired > n.x else (-1 if desired < n.x else 0)
                        last_dir = direction or last_dir
                        if awaiting_resume_off is not None:
                            local = wx - n.x
                            if abs(local - awaiting_resume_off) < 8:
                                awaiting_resume_off = None
                        else:
                            nx, jumped, refuse = proposed_x_legal(n, desired, state, direction)
                            if refuse:
                                set_status(refuse)
                            if jumped and nx != desired and direction != 0:
                                awaiting_resume_off = drag_grab_off
                            n.x = nx
                        if n.elevator != "none":
                            apply_elevator_x(state, n.elevator, n.x, assets, anchor=n)
                        apply_node_stickers(n, stickers_dragged_with, state, state.floor_count())
            elif ev.type == pygame.KEYUP:
                add_key = shortcuts.get("add_sticker") if shortcuts else None
                if add_key and ev.key == add_key and not (hide_stickers or lock_stickers):
                    cur = next((s for s in state.stickers if s.id == selected_sticker), None) if selected_sticker else None
                    if cur is not None and path_dot_color(cur.name) and not path_v_used:
                        add_sticker_from_ui()
                    path_v_used = False
                hotkey_held.discard(ev.key)
            elif ev.type == pygame.KEYDOWN:
                mods = pygame.key.get_mods()
                if (mods & pygame.KMOD_CTRL) and ev.key == pygame.K_s:
                    do_export_json()
                    continue
                if (mods & pygame.KMOD_CTRL) and ev.key == pygame.K_r:
                    do_render_png()
                    continue
                if (mods & pygame.KMOD_CTRL) and ev.key == pygame.K_f:
                    search_open = True
                    active_field = "search"
                    field_sel["search"] = (0, len(fields.get("search") or ""))
                    continue
                if active_field:
                    txt = fields[active_field]
                    sel = field_sel.get(active_field)
                    if ev.key == pygame.K_a and (mods & pygame.KMOD_CTRL):
                        field_sel[active_field] = (0, len(txt))
                    elif ev.key == pygame.K_LEFT:
                        i = sel[1] if sel else len(txt)
                        i = max(0, i - 1)
                        if mods & pygame.KMOD_SHIFT:
                            a = sel[0] if sel else i + 1
                            field_sel[active_field] = (a, i)
                        else:
                            field_sel[active_field] = (i, i)
                    elif ev.key == pygame.K_RIGHT:
                        i = sel[1] if sel else len(txt)
                        i = min(len(txt), i + 1)
                        if mods & pygame.KMOD_SHIFT:
                            a = sel[0] if sel else i - 1
                            field_sel[active_field] = (a, i)
                        else:
                            field_sel[active_field] = (i, i)
                    elif ev.key == pygame.K_HOME:
                        field_sel[active_field] = (0, 0)
                    elif ev.key == pygame.K_END:
                        field_sel[active_field] = (len(txt), len(txt))
                    elif ev.key in (pygame.K_BACKSPACE, pygame.K_DELETE) and sel and sel[0] != sel[1]:
                        a, b = sorted(sel)
                        fields[active_field] = txt[:a] + txt[b:]
                        field_sel[active_field] = (a, a)
                    elif ev.key == pygame.K_BACKSPACE:
                        i = sel[1] if sel else len(txt)
                        i = max(0, min(len(txt), i))
                        if i > 0:
                            fields[active_field] = txt[:i - 1] + txt[i:]
                            field_sel[active_field] = (i - 1, i - 1)
                    elif ev.key == pygame.K_DELETE:
                        i = sel[1] if sel else len(txt)
                        i = max(0, min(len(txt), i))
                        if i < len(txt):
                            fields[active_field] = txt[:i] + txt[i + 1:]
                            field_sel[active_field] = (i, i)
                    elif ev.key == pygame.K_RETURN:
                        commit_field(active_field)
                        active_field = None
                        selecting_field = None
                    elif ev.key == pygame.K_ESCAPE:
                        if active_field in field_backup:
                            fields[active_field] = field_backup[active_field]
                        active_field = None
                        selecting_field = None
                    elif ev.key == pygame.K_TAB:
                        commit_field(active_field)
                        keys = list(fields.keys())
                        i = keys.index(active_field) if active_field in keys else -1
                        nxt = keys[(i + 1) % len(keys)]
                        field_backup[nxt] = fields.get(nxt, "")
                        active_field = nxt
                        field_sel[active_field] = (0, len(fields[active_field]))
                    else:
                        ch = ev.unicode
                        if ev.key in (pygame.K_MINUS, pygame.K_KP_MINUS) and not ch:
                            if active_field in ("floor", "base"):
                                ch = "-"
                        if ch and ch.isprintable():
                            if active_field == "stars" and not ch.isdigit():
                                ch = ""
                            if active_field in ("floor", "base") and ch not in "-0123456789":
                                ch = ""
                            if active_field in ("sticker_level", "sticker_amount"):
                                if not ch.isalnum():
                                    ch = ""
                                elif len((fields.get(active_field) or "")) >= 2:
                                    sel = field_sel.get(active_field)
                                    if not (sel and sel[0] != sel[1]):
                                        ch = ""
                            if ch:
                                if sel and sel[0] != sel[1]:
                                    a, b = sorted(sel)
                                    fields[active_field] = txt[:a] + ch + txt[b:]
                                    field_sel[active_field] = (a + 1, a + 1)
                                else:
                                    i = sel[1] if sel else len(txt)
                                    i = max(0, min(len(txt), i))
                                    fields[active_field] = txt[:i] + ch + txt[i:]
                                    field_sel[active_field] = (i + 1, i + 1)
                elif shortcuts:
                    names = [k for k, v in shortcuts.items() if v == ev.key]
                    name = names[0] if names else None
                    if ev.key in hotkey_held and name not in ("delete_sticker",):
                        pass
                    else:
                        hotkey_held.add(ev.key)
                        if connect_mode and (
                                ev.key == shortcuts.get("cancel_connect")
                                or ev.key == shortcuts.get("delete_port")):
                            cancel_connect("Connection cancelled.")
                        elif name == "delete_sticker" and selected_sticker:
                            despawn_selected_sticker()
                        elif name == "center_camera" and not connect_mode:
                            H = state.floor_count() * FLOOR_H
                            cr2 = canvas_rect(sw, sh)
                            cam_x = MAP_W / 2 - (cr2.w / zoom) / 2
                            cam_y = H / 2 - (cr2.h / zoom) / 2
                            set_status("Camera centered.")
                        elif name == "update_node" and selected_node:
                            n = state.find_by_id(selected_node)
                            if n and read_form_into(n):
                                if n.elevator != "none":
                                    apply_elevator_x(state, n.elevator, n.x, assets, anchor=n)
                                set_status(f"Updated {n.title}")
                        elif name == "toggle_floor":
                            show_floor_ruler = not show_floor_ruler
                        elif name == "toggle_hide":
                            hide_mode = (hide_mode + 1) % 3
                            hide_paths = hide_mode >= 1
                            hide_stickers = hide_mode >= 2
                            if hide_stickers:
                                selected_sticker = None
                                dragging_sticker = None
                        elif name == "toggle_lock":
                            lock_stickers = not lock_stickers
                        elif name == "add_sticker" and not (hide_stickers or lock_stickers):
                            cur = next((s for s in state.stickers if s.id == selected_sticker), None) if selected_sticker else None
                            if cur is not None and path_dot_color(cur.name):
                                path_v_used = False
                            else:
                                add_sticker_from_ui()
                        elif name == "toggle_sticker_big" and selected_sticker:
                            st = next((s for s in state.stickers if s.id == selected_sticker), None)
                            if st:
                                st.big = not st.big
                                st.tile_x, st.tile_y = clamp_sticker_xy(
                                    st.tile_x, st.tile_y, state, assets, st.name, st.big)
                        elif name == "cycle_port_color" and selected_node and focused_port:
                            n = state.find_by_id(selected_node)
                            if n and (n.ports[focused_port].get("gate") or "") != "closed-gate":
                                cur = port_color.get(focused_port, n.ports[focused_port].get("color", "cyan"))
                                try:
                                    i = COLOR_ORDER.index(cur)
                                except ValueError:
                                    i = 0
                                nxt = COLOR_ORDER[(i + 1) % len(COLOR_ORDER)]
                                port_color[focused_port] = nxt
                                sync_link_color(n, focused_port, nxt, state)
                        elif name == "cycle_port_gate" and selected_node and focused_port:
                            n = state.find_by_id(selected_node)
                            if n:
                                gcur = port_gate.get(focused_port, n.ports[focused_port].get("gate", "open"))
                                if gcur in ("open-gate", "none", ""):
                                    gcur = "open"
                                try:
                                    gi = GATES.index(gcur)
                                except ValueError:
                                    gi = 0
                                nxt = GATES[(gi + 1) % len(GATES)]
                                port_gate[focused_port] = nxt
                                n.ports[focused_port]["gate"] = nxt
                        elif name in PORT_HOTKEY_ACTIONS and selected_node:
                            pk = PORT_HOTKEY_ACTIONS[name]
                            n = state.find_by_id(selected_node)
                            if n:
                                if connect_mode and connect_src_id:
                                    src = state.find_by_id(connect_src_id)
                                    if src and n.id == src.id and pk == connect_src_port:
                                        cancel_connect("Connection cancelled.")
                                        continue
                                    used = bool((n.ports[pk].get("target") or "").strip())
                                    if src and n.id == src.id:
                                        srcp = src.ports.get(connect_src_port, {})
                                        src_tgt = (srcp.get("target") or "").strip()
                                        same_kind = connect_src_port and (
                                            pk.startswith("top") == connect_src_port.startswith("top"))
                                        if pk != connect_src_port and not used and same_kind and src_tgt:
                                            src.ports[pk]["color"] = srcp.get("color", "cyan")
                                            src.ports[pk]["gate"] = srcp.get("gate", "open")
                                            src.ports[pk]["target"] = src_tgt
                                            srcp["target"] = ""
                                            set_focused_port(pk)
                                            cancel_connect(f"Port moved to {pk}")
                                    elif src and n.id != src.id and port_side_ok(connect_src_port, pk) and dest_floor_ok(src, connect_src_port, n):
                                        clear_port_link(src, connect_src_port, state)
                                        clear_port_link(n, pk, state)
                                        make_port_link(src, connect_src_port, n, pk, state)
                                        set_focused_port(pk)
                                        fill_form_from_node(n)
                                        set_focused_port(pk)
                                        cancel_connect(f"Linked {src.title} ↔ {n.title}")
                                else:
                                    port_color[pk] = n.ports[pk].get("color", "cyan")
                                    port_gate[pk] = n.ports[pk].get("gate", "none")
                                    if focused_port != pk:
                                        set_focused_port(pk)
                                    else:
                                        set_focused_port(pk)
                                        lo, hi = state.min_floor(), state.max_floor()
                                        if pk.startswith("und") and n.floor == lo:
                                            clear_port_link(n, pk, state)
                                            n.ports[pk]["target"] = EDGE_TARGET
                                            set_status(f"Edge line down from {n.title}")
                                        elif pk.startswith("top") and n.floor == hi:
                                            clear_port_link(n, pk, state)
                                            n.ports[pk]["target"] = EDGE_TARGET
                                            set_status(f"Edge line up from {n.title}")
                                        else:
                                            connect_mode = "pick_node"
                                            connect_src_id = n.id
                                            connect_src_port = pk
                                            connect_dest_id = None
                                            set_status("doing port connection")
                    if ev.key == pygame.K_DELETE and selected_node:
                        despawn_selected_node()
                    elif ev.key == pygame.K_DELETE and selected_sticker:
                        despawn_selected_sticker()
                    elif ev.key == pygame.K_ESCAPE:
                        selected_node = None
                        selected_sticker = None
                    elif ev.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
                        zoom = clamp(zoom * 1.1, 0.2, 2.0)
                    elif ev.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                        zoom = clamp(zoom / 1.1, 0.2, 2.0)
                else:
                    if ev.key == pygame.K_DELETE and selected_node:
                        despawn_selected_node()
                    elif ev.key == pygame.K_DELETE and selected_sticker:
                        despawn_selected_sticker()
                    elif ev.key == pygame.K_ESCAPE:
                        selected_node = None
                        selected_sticker = None
                    elif ev.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
                        zoom = clamp(zoom * 1.1, 0.2, 2.0)
                    elif ev.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                        zoom = clamp(zoom / 1.1, 0.2, 2.0)

        caret_blink += 1

        # ---- draw map (visible band only + cache) ----
        screen.fill((22, 22, 26))
        cr = canvas_rect(sw, sh)
        world_h = state.floor_count() * FLOOR_H
        vis_w = max(1, int(math.ceil(cr.w / zoom)) + 2)
        vis_h = max(1, int(math.ceil(cr.h / zoom)) + 2)
        left_c = int(max(0, min(MAP_W - 1, math.floor(cam_x))))
        top_c = int(max(0, min(world_h - 1, math.floor(cam_y))))
        right_c = int(min(MAP_W, max(left_c + 1, math.ceil(cam_x + vis_w))))
        bottom_c = int(min(world_h, max(top_c + 1, math.ceil(cam_y + vis_h))))
        view_box = (left_c, top_c, right_c, bottom_c)
        now = pygame.time.get_ticks()
        red_blink = (now // 4000) % 2 == 0
        view_sig = (
            hide_stickers, hide_paths, hide_mode, flip_bg, selected_node, selected_sticker, red_blink, round(zoom, 3), view_box,
            tuple((c, tuple((state.path_routes.get(c) or {}).get("ids") or []),
                   (state.path_routes.get(c) or {}).get("dir", 1)) for c in PATH_DOT_COLORS),
            tuple((n.id, n.floor, n.x, n.elevator, getattr(n, "roof", False), getattr(n, "elev_dx", 0), n.title, n.material, n.stars, getattr(n, "mat_right", False), getattr(n, "tengoku", False), getattr(n, "jigoku", False),
                   tuple((k, n.ports[k].get("target"), n.ports[k].get("color"), n.ports[k].get("gate"))
                         for k in PORT_KEYS))
                  for n in state.nodes),
            tuple((s.id, s.name, s.tile_x, s.tile_y, getattr(s, "big", False), getattr(s, "level", ""), getattr(s, "amount", "")) for s in state.stickers),
        )
        if view_cache["sig"] != view_sig:
            band = renderer.render(
                state,
                crop=False,
                selected_node=selected_node,
                selected_sticker=None,
                view_box=view_box,
                hide_stickers=hide_stickers,
                hide_paths=hide_paths,
                live=True,
                red_blink=red_blink,
                flip_bg=flip_bg,
            )
            surf = pil_to_surf(band.convert("RGBA"))
            tw = max(1, int(round(band.width * zoom)))
            th = max(1, int(round(band.height * zoom)))
            view_cache["surf"] = pygame.transform.scale(surf, (tw, th))
            view_cache["box"] = view_box
            view_cache["sig"] = view_sig
        cached = view_cache["surf"]
        if cached is not None:
            bx0, by0 = view_cache["box"][0], view_cache["box"][1]
            blit_x = cr.x + int(round((bx0 - cam_x) * zoom))
            blit_y = cr.y + int(round((by0 - cam_y) * zoom))
            screen.set_clip(cr)
            screen.blit(cached, (blit_x, blit_y))
            if selected_sticker and not hide_stickers:
                st = next((s for s in state.stickers if s.id == selected_sticker), None)
                if st is not None:
                    w, h = sticker_size(st.name, assets, getattr(st, "big", False))
                    sx = cr.x + int(round((st.tile_x - cam_x) * zoom))
                    sy = cr.y + int(round((st.tile_y - cam_y) * zoom))
                    pygame.draw.rect(screen, (255, 255, 255),
                                     Rect(sx, sy, int(round(w * zoom)), int(round(h * zoom))), 2)
            if show_floor_ruler:
                if floor_box_surf is None:
                    pbox = assets.get("floor_number_box")
                    if pbox is None:
                        pbox = Image.new("RGBA", FLOOR_BOX, (18, 18, 18, 230))
                    floor_box_surf = pil_to_surf(pbox.convert("RGBA"))
                fc = state.floor_count()
                bw, bh = floor_box_surf.get_width(), floor_box_surf.get_height()
                for fi in range(fc):
                    top = floor_top_y(fi, fc)
                    by = top + int(bh * 2)
                    sy = cr.y + int(round((by - cam_y) * zoom))
                    if sy + bh < cr.y or sy > cr.bottom:
                        continue
                    sx = cr.x + 4
                    screen.blit(floor_box_surf, (sx, sy))
                    lab = floor_label(state.min_floor() + fi)
                    ts = ui_font.render(lab, True, (255, 255, 255))
                    screen.blit(ts, (sx + (bw - ts.get_width()) // 2,
                                     sy + (bh - ts.get_height()) // 2 - 1))
            screen.set_clip(None)

        # floor scrollbar
        sr = scroll_rect(sw, sh)
        pygame.draw.rect(screen, (28, 28, 32), sr)
        pygame.draw.rect(screen, (70, 70, 78), sr, 1)
        world_h = state.floor_count() * FLOOR_H
        view_h = cr.h / max(0.05, zoom)
        max_cam = max(0.0, world_h - view_h)
        steps = max(1, int(math.ceil(max_cam / FLOOR_H))) if max_cam > 0 else 1
        thumb_h = max(22, int(sr.h / (steps + 1)))
        step = int(clamp(round(cam_y / FLOOR_H), 0, steps))
        ty = sr.y + int((sr.h - thumb_h) * (step / steps if steps else 0))
        pygame.draw.rect(screen, (130, 130, 140), Rect(sr.x + 2, ty, sr.w - 4, thumb_h), border_radius=3)

        q = fold_search(fields.get("search") or "") if search_open else ""
        if search_open and q:
            def _scr(wx, wy):
                return (cr.x + int(round((wx - cam_x) * zoom)),
                        cr.y + int(round((wy - cam_y) * zoom)))
            fc = state.floor_count()
            mf = state.min_floor()
            for n in state.nodes:
                hit_n = q in fold_search(n.title)
                hit_m = q in fold_search(n.material or "")
                if hit_n or hit_m:
                    ny = node_y_on_floor(n.floor, fc, mf)
                    sx, sy = _scr(n.x, ny)
                    rr = Rect(sx - 2, sy - 2, int(NODE_W * zoom) + 4, int(NODE_H * zoom) + 4)
                    pygame.draw.rect(screen, (240, 210, 40), rr, 2, border_radius=6)
            if not hide_stickers:
                for st in state.stickers:
                    if hide_paths and path_dot_color(st.name):
                        continue
                    if q not in fold_search(st.name):
                        continue
                    x, y = sticker_world(st)
                    w, h = sticker_size(st.name, assets, getattr(st, "big", False))
                    sx, sy = _scr(x, y)
                    rr = Rect(sx - 2, sy - 2, int(w * zoom) + 4, int(h * zoom) + 4)
                    pygame.draw.rect(screen, (240, 210, 40), rr, 2, border_radius=5)

        if search_open:
            sbox = Rect(cr.right - 228, cr.y + 6, 200, 22)
            field_box(screen, "search", sbox, mouse, click)
            xbtn = Rect(sbox.right + 4, sbox.y, 22, 22)
            pygame.draw.rect(screen, (70, 40, 40), xbtn, border_radius=3)
            pygame.draw.rect(screen, (200, 80, 80), xbtn, 1, border_radius=3)
            xt = ui_font_b.render("X", True, (240, 240, 240))
            screen.blit(xt, (xbtn.x + (xbtn.w - xt.get_width()) // 2,
                             xbtn.y + (xbtn.h - xt.get_height()) // 2))

        pygame.draw.rect(screen, (10, 10, 12), cr, 1)
        if connect_mode:
            msg = "doing port connection"
            ts = ui_font_b.render(msg, True, (80, 220, 110))
            msg_x = cr.right - ts.get_width() - 12
            msg_y = cr.bottom - ts.get_height() - 8
            cancel_r = Rect(msg_x + ts.get_width() - 88, msg_y - 30, 88, 24)
            if cancel_r.right > cr.right - 8:
                cancel_r.x = cr.right - 96
            pygame.draw.rect(screen, (180, 40, 40), cancel_r, border_radius=3)
            pygame.draw.rect(screen, (255, 255, 255), cancel_r, 2, border_radius=3)
            cl = ui_font_b.render("CANCEL", True, (255, 255, 255))
            screen.blit(cl, (cancel_r.x + (cancel_r.w - cl.get_width()) // 2,
                             cancel_r.y + (cancel_r.h - cl.get_height()) // 2))
            screen.blit(ts, (msg_x, msg_y))
            if click and cancel_r.collidepoint(mouse):
                cancel_connect()

        # ---- side panel ----
        panel = Rect(sw - 420, 0, 420, sh - 28)
        pygame.draw.rect(screen, (32, 32, 38), panel)
        bg_key = (panel.w, panel.h)
        if panel_bg_cache.get("key") != bg_key:
            panel_bg_cache["key"] = bg_key
            panel_bg_cache["surf"] = load_panel_background(panel.w, panel.h)
        if panel_bg_cache.get("surf") is not None:
            screen.blit(panel_bg_cache["surf"], panel.topleft)
        pygame.draw.line(screen, (80, 80, 90), (panel.x, 0), (panel.x, sh), 2)

        x0 = panel.x + 10
        y = 8

        # file row
        field_box(screen, "export_name", Rect(x0, y + 14, 136, 22), mouse, click, "Export name")
        if button(screen, "import", Rect(x0 + 144, y + 14, 64, 22), "Import", mouse, click):
            path = native_file_dialog("open", "Import map JSON",
                                     [("JSON", "*.json"), ("All files", "*.*")], SCRIPT_DIR)
            if path and os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as f:
                    state.load_dict(json.load(f), assets)
                base = os.path.splitext(os.path.basename(path))[0]
                fields["export_name"] = base
                state.name = base
                prefs = apply_ui_prefs(getattr(state, "ui", {}), assets)
                lock_stickers = prefs["lock_stickers"]
                hide_mode = prefs["hide_mode"]
                hide_paths = hide_mode >= 1
                hide_stickers = hide_mode >= 2
                show_floor_ruler = prefs["show_floor_ruler"]
                flip_bg = prefs["flip_bg"]
                assets.starred_folders = prefs["starred"]
                collapsed_cats = prefs["collapsed"]
                if prefs["starred"]:
                    assets.reload_images()
                last_saved_sig = saved_map_fingerprint()
                set_status(f"Imported {path}")
            elif path:
                set_status(f"No file {path}")
        if button(screen, "exportj", Rect(x0 + 212, y + 14, 88, 22), "Export JSON", mouse, click):
            do_export_json()
        if button(screen, "render", Rect(x0 + 304, y + 14, 56, 22), "Render", mouse, click):
            do_render_png()
        y += 44
        if button(screen, "center", Rect(x0, y, 54, 22), "Center", mouse, click):
            H = state.floor_count() * FLOOR_H
            cr2 = canvas_rect(sw, sh)
            cam_x = MAP_W / 2 - (cr2.w / zoom) / 2
            cam_y = H / 2 - (cr2.h / zoom) / 2
            set_status("Camera centered.")
        lock_stickers = checkbox(screen, Rect(x0 + 62, y + 3, 16, 16), lock_stickers,
                                 "Lock ☻", mouse, click)
        hide_box = Rect(x0 + 158, y + 3, 16, 16)
        hide_fill = (40, 40, 48) if hide_mode == 0 else ((70, 70, 40) if hide_mode == 1 else (60, 140, 60))
        pygame.draw.rect(screen, hide_fill, hide_box, border_radius=2)
        pygame.draw.rect(screen, (200, 200, 200), hide_box, 1, border_radius=2)
        if hide_mode == 1:
            pygame.draw.line(screen, (240, 240, 140), (hide_box.x + 3, hide_box.centery),
                             (hide_box.right - 3, hide_box.centery), 2)
        elif hide_mode >= 2:
            pygame.draw.line(screen, (240, 240, 240), (hide_box.x + 3, hide_box.y + 8),
                             (hide_box.x + 7, hide_box.y + 13), 2)
            pygame.draw.line(screen, (240, 240, 240), (hide_box.x + 7, hide_box.y + 13),
                             (hide_box.x + 14, hide_box.y + 3), 2)
        screen.blit(ui_font_sm.render("Hide ☻", True, (220, 220, 220)), (hide_box.right + 6, hide_box.y + 1))
        if click and hide_box.collidepoint(mouse):
            hide_mode = (hide_mode + 1) % 3
            hide_paths = hide_mode >= 1
            hide_stickers = hide_mode >= 2
            if hide_stickers:
                selected_sticker = None
                dragging_sticker = None
        show_floor_ruler = checkbox(screen, Rect(x0 + 230, y + 3, 16, 16), show_floor_ruler,
                                    "Floor", mouse, click)
        if button(screen, "basego", Rect(x0 + 292, y, 40, 22), "Base", mouse, click):
            raw = (fields["base"] or "").strip().upper()
            if raw in ("B1", "B-1", "B01"):
                new_base = 0
            else:
                try:
                    new_base = int(raw)
                except ValueError:
                    new_base = None
            if new_base is None:
                set_status("REFUSED: base must be an integer (0 / B1 or negative)")
            elif not state.nodes:
                set_status("No nodes to rebase.")
            else:
                old_min = state.min_floor()
                delta = new_base - old_min
                if delta != 0:
                    for n in state.nodes:
                        n.floor += delta
                    prune_edge_ports(state)
                    if selected_node:
                        sn = state.find_by_id(selected_node)
                        if sn:
                            fields["floor"] = str(sn.floor)
                set_status(f"Base is now {floor_label(state.min_floor())}")
        field_box(screen, "base", Rect(x0 + 336, y, 40, 22), mouse, click)
        y += 34
        pygame.draw.line(screen, (70, 70, 80), (x0, y), (panel.right - 10, y))
        y += 8
        draw_text(screen, "NODE", (x0, y), ui_font_b, (180, 200, 255))
        y += 20
        field_box(screen, "title", Rect(x0, y + 14, 280, 22), mouse, click, "Title")
        field_box(screen, "floor", Rect(x0 + 290, y + 14, 110, 22), mouse, click, "Floor # (0=B1)")
        y += 44

        draw_text(screen, "Ports", (x0, y), ui_font_sm, (160, 160, 160))
        draw_text(screen, "color / gate", (x0 + 210, y), ui_font_sm, (160, 160, 160))
        y += 16
        viz = Rect(x0, y, 196, 118)
        pygame.draw.rect(screen, (28, 28, 34), viz, border_radius=4)
        pygame.draw.rect(screen, (90, 90, 100), viz, 1, border_radius=4)
        # wire frame
        pygame.draw.line(screen, (160, 160, 170), (viz.x + 22, viz.y + 22), (viz.x + 22, viz.y + 96), 1)
        pygame.draw.line(screen, (160, 160, 170), (viz.x + 22, viz.y + 96), (viz.x + 174, viz.y + 96), 1)
        pygame.draw.line(screen, (160, 160, 170), (viz.x + 174, viz.y + 96), (viz.x + 174, viz.y + 22), 1)
        pygame.draw.line(screen, (160, 160, 170), (viz.x + 174, viz.y + 22), (viz.x + 22, viz.y + 22), 1)
        port_ui = {
            "top_left": (viz.x + 10, viz.y + 8),
            "top_mid": (viz.x + 86, viz.y + 8),
            "top_right": (viz.x + 162, viz.y + 8),
            "und_left": (viz.x + 10, viz.y + 90),
            "und_mid": (viz.x + 86, viz.y + 90),
            "und_right": (viz.x + 162, viz.y + 90),
        }
        cur_node = state.find_by_id(selected_node) if selected_node else None
        src_conn = state.find_by_id(connect_src_id) if connect_mode and connect_src_id else None
        for pk, (px, py) in port_ui.items():
            pr = Rect(px, py, 22, 22)
            used = bool(cur_node and (cur_node.ports[pk].get("target") or "").strip())
            eligible = True
            if connect_mode and src_conn and connect_src_port and cur_node:
                empty = not used
                same = cur_node.id == src_conn.id
                if same:
                    src_tgt = str((src_conn.ports.get(connect_src_port) or {}).get("target") or "").strip()
                    src_has = bool(src_tgt)
                    same_kind = pk.startswith("top") == connect_src_port.startswith("top")
                    eligible = bool(src_has) and pk != connect_src_port and empty and same_kind
                else:
                    eligible = port_side_ok(connect_src_port, pk) and dest_floor_ok(src_conn, connect_src_port, cur_node)
            if focused_port == pk and used:
                fill = (50, 190, 70) if ((pygame.time.get_ticks() - port_focus_at) // 1000) % 2 == 0 else (130, 130, 135)
            elif focused_port == pk:
                fill = (50, 190, 70)
            elif connect_mode and not eligible:
                fill = (28, 28, 32)
            elif used:
                fill = (130, 130, 135)
            else:
                fill = (18, 18, 22)
            pygame.draw.rect(screen, fill, pr, border_radius=2)
            pygame.draw.rect(screen, (70, 70, 75) if (connect_mode and not eligible) else (200, 200, 200), pr, 1, border_radius=2)
            if click and pr.collidepoint(mouse):
                if connect_mode and cur_node and connect_src_id == cur_node.id and pk == connect_src_port:
                    cancel_connect("Connection cancelled.")
                elif connect_mode and cur_node and not eligible:
                    pass
                elif connect_mode and cur_node:
                    src = state.find_by_id(connect_src_id) if connect_src_id else None
                    empty = not (cur_node.ports[pk].get("target") or "").strip()
                    same_kind = connect_src_port and (
                        pk.startswith("top") == connect_src_port.startswith("top"))
                    srcp = src.ports.get(connect_src_port, {}) if src else {}
                    src_tgt = (srcp.get("target") or "").strip()
                    if (src and cur_node.id == src.id and pk != connect_src_port
                            and empty and same_kind and src_tgt):
                        src.ports[pk]["color"] = srcp.get("color", "cyan")
                        src.ports[pk]["gate"] = srcp.get("gate", "open")
                        src.ports[pk]["target"] = src_tgt
                        srcp["target"] = ""
                        set_focused_port(pk)
                        port_color[pk] = src.ports[pk].get("color", "cyan")
                        port_gate[pk] = src.ports[pk].get("gate", "open")
                        fill_form_from_node(src)
                        set_focused_port(pk)
                        cancel_connect(f"Port moved to {pk}")
                    elif src and cur_node.id != src.id and port_side_ok(connect_src_port, pk) and dest_floor_ok(src, connect_src_port, cur_node):
                        clear_port_link(src, connect_src_port, state)
                        clear_port_link(cur_node, pk, state)
                        make_port_link(src, connect_src_port, cur_node, pk, state)
                        set_focused_port(pk)
                        fill_form_from_node(cur_node)
                        cancel_connect(f"Linked {src.title} ↔ {cur_node.title}")
                else:
                    set_focused_port(pk)
                    if cur_node:
                        port_color[pk] = cur_node.ports[pk].get("color", "cyan")
                        port_gate[pk] = cur_node.ports[pk].get("gate", "none")
        # connected-to + color/gate/start only while a port square is focused
        cx0 = x0 + 206
        cy0 = y
        start_r = None
        if selected_node and not focused_port:
            want_t = checkbox(screen, Rect(cx0, cy0 + 8, 16, 16), tengoku_sel, "Tengoku", mouse, click)
            want_j = checkbox(screen, Rect(cx0, cy0 + 32, 16, 16), jigoku_sel, "Jigoku", mouse, click)
            rn = state.find_by_id(selected_node)
            if rn is not None:
                if want_t != tengoku_sel:
                    err = apply_zone_flag(state, rn, "tengoku", want_t)
                    if err:
                        set_status(err)
                    tengoku_sel = bool(getattr(rn, "tengoku", False))
                    jigoku_sel = bool(getattr(rn, "jigoku", False))
                elif want_j != jigoku_sel:
                    err = apply_zone_flag(state, rn, "jigoku", want_j)
                    if err:
                        set_status(err)
                    tengoku_sel = bool(getattr(rn, "tengoku", False))
                    jigoku_sel = bool(getattr(rn, "jigoku", False))
        if focused_port:
            draw_text(screen, "connected to:", (viz.x + 48, viz.y + 40), ui_font_sm, (180, 180, 180))
            link_name = ""
            if cur_node:
                link_name = (cur_node.ports[focused_port].get("target") or "").strip()
            pygame.draw.rect(screen, (12, 12, 14), Rect(viz.x + 36, viz.y + 56, 124, 20))
            pygame.draw.rect(screen, (70, 70, 80), Rect(viz.x + 36, viz.y + 56, 124, 20), 1)
            if link_name == EDGE_TARGET:
                link_name = "edge"
            if link_name:
                draw_text(screen, link_name[:16], (viz.x + 40, viz.y + 58), ui_font_sm, (230, 230, 230))

            for i, ck in enumerate(COLOR_ORDER):
                swatch = Rect(cx0 + i * 28, cy0, 24, 24)
                pygame.draw.rect(screen, CONN_COLORS[ck], swatch, border_radius=3)
                if port_color.get(focused_port) == ck:
                    pygame.draw.rect(screen, (255, 255, 255), swatch, 2, border_radius=3)
                if click and swatch.collidepoint(mouse):
                    port_color[focused_port] = ck
                    if cur_node:
                        sync_link_color(cur_node, focused_port, ck, state)
            gy = cy0 + 32
            gcur = port_gate[focused_port]
            if gcur in ("open-gate", "none", ""):
                gcur = "open"
            draw_gate_lock(screen, cx0, gy + 2, gcur)
            glabel = GATE_LABELS.get(gcur, gcur)
            if button(screen, "gatef", Rect(cx0 + 22, gy, 88, 24), glabel, mouse, click):
                try:
                    gi = GATES.index(gcur)
                except ValueError:
                    gi = 0
                port_gate[focused_port] = GATES[(gi + 1) % len(GATES)]
                if cur_node:
                    cur_node.ports[focused_port]["gate"] = port_gate[focused_port]
            draw_text(screen, port_color.get(focused_port, "cyan"),
                      (cx0 + 114, gy + 4), ui_font, CONN_COLORS[port_color.get(focused_port, "cyan")])
            start_r = Rect(cx0, gy + 32, 88, 26)
            start_on = connect_mode is not None
            pygame.draw.rect(screen, (90, 40, 40) if start_on else (48, 48, 54), start_r, border_radius=4)
            pygame.draw.rect(screen, (220, 80, 80) if start_on else (140, 140, 145), start_r, 2, border_radius=4)
            sl = ui_font.render("Cancel" if start_on else "Start", True, (240, 240, 240))
            screen.blit(sl, (start_r.x + (start_r.w - sl.get_width()) // 2,
                             start_r.y + (start_r.h - sl.get_height()) // 2))
            if click and start_r.collidepoint(mouse) and cur_node:
                if connect_mode:
                    cancel_connect("Connection cancelled.")
                else:
                    lo, hi = state.min_floor(), state.max_floor()
                    fp = focused_port or ""
                    if fp.startswith("und") and cur_node.floor == lo:
                        clear_port_link(cur_node, fp, state)
                        cur_node.ports[fp]["target"] = EDGE_TARGET
                        cancel_connect(f"Edge line down from {cur_node.title}")
                    elif fp.startswith("top") and cur_node.floor == hi:
                        clear_port_link(cur_node, fp, state)
                        cur_node.ports[fp]["target"] = EDGE_TARGET
                        cancel_connect(f"Edge line up from {cur_node.title}")
                    else:
                        connect_mode = "pick_node"
                        connect_src_id = cur_node.id
                        connect_src_port = focused_port
                        connect_dest_id = None
                        set_status("doing port connection")
            if button(screen, "rmport", Rect(cx0 + 96, gy + 32, 88, 26), "Remove", mouse, click):
                if cur_node:
                    clear_port_link(cur_node, focused_port, state)
                    set_status("Connection removed.")
        y += 126

        draw_text(screen, "Elevator:", (x0, y), ui_font_sm, (160, 160, 160))
        y += 16
        elev_sel, exx, _ = radio_row(screen, x0, y, ELEVATOR_KINDS, elev_sel, mouse, click, "el")
        roof_sel = checkbox(screen, Rect(exx + 6, y + 1, 16, 16), roof_sel, "Roof", mouse, click)
        if selected_node:
            rn = state.find_by_id(selected_node)
            if rn is not None and bool(getattr(rn, "roof", False)) != bool(roof_sel):
                if roof_sel:
                    rn.roof = True
                else:
                    upper = None
                    if rn.elevator not in ("", "none"):
                        uppers = [o for o in state.elevator_group(rn.elevator)
                                  if o.id != rn.id and o.floor > rn.floor]
                        if uppers:
                            upper = min(uppers, key=lambda o: o.floor)
                    if upper is None:
                        rn.roof = False
                    else:
                        members = list(state.elevator_segment(rn))
                        skip = {m.id for m in members}
                        ok = True
                        for m in members:
                            ivals = []
                            for o in state.nodes_on_floor(m.floor):
                                if o.id in skip:
                                    continue
                                ivals.append((o.x, o.x + NODE_W))
                            if not slot_fits(upper.x, merge_intervals(ivals)):
                                ok = False
                                break
                        if ok:
                            rn.roof = False
                            apply_elevator_x(state, rn.elevator, upper.x, assets, anchor=rn)
                        else:
                            roof_sel = True
                            set_status("REFUSED: no space to join elevator rig above")
        y += 24

        draw_text(screen, "Material:", (x0, y), ui_font_sm, (160, 160, 160))
        y += 16
        # wrap materials
        xx, yy = x0, y
        for m in MATERIALS:
            label = MATERIAL_LABELS.get(m, m)
            r = Rect(xx, yy, 8 + ui_font_sm.size(label)[0] + 14, 18)
            on = mat_sel == m
            pygame.draw.rect(screen, (70, 70, 40) if on else (40, 40, 48), r, border_radius=3)
            pygame.draw.rect(screen, (220, 200, 120) if on else (80, 80, 90), r, 1, border_radius=3)
            screen.blit(ui_font_sm.render(label, True, (230, 230, 230)), (r.x + 6, r.y + 2))
            if click and r.collidepoint(mouse):
                mat_sel = m
            xx = r.right + 4
            if m == "Fabric" or xx > panel.right - 80:
                xx = x0
                yy += 20
        y = yy + 24
        field_box(screen, "stars", Rect(x0, y + 14, 80, 22), mouse, click, "Stars")
        mat_right_sel = checkbox(screen, Rect(x0 + 100, y + 16, 16, 16), mat_right_sel, "Right", mouse, click)
        if selected_node:
            rn = state.find_by_id(selected_node)
            if rn is not None:
                rn.mat_right = bool(mat_right_sel)
        y += 44

        floor_valid = parse_floor_text(fields["floor"]) is not None
        add_rect = Rect(x0, y, 130, 26)
        if floor_valid:
            add_clicked = button(screen, "addn", add_rect, "Add", mouse, click)
        else:
            pygame.draw.rect(screen, (40, 40, 44), add_rect, border_radius=3)
            pygame.draw.rect(screen, (80, 80, 80), add_rect, 1, border_radius=3)
            ts = ui_font.render("Add", True, (110, 110, 110))
            screen.blit(ts, (add_rect.x + (add_rect.w - ts.get_width()) // 2,
                             add_rect.y + (add_rect.h - ts.get_height()) // 2))
            add_clicked = False
        if add_clicked:
            fl = int(fields["floor"])
            title = fields["title"].strip() or "NEW"
            existing = state.find_by_title(title)
            if existing:
                set_status("REFUSED: that node name already exists")
            elif elevator_on_floor(state, elev_sel, fl):
                set_status(f"REFUSED: {elev_sel} elevator already on {floor_label(fl)}")
            else:
                sx = spawn_x_for_floor(state, fl, elev_sel)
                if sx is None:
                    set_status("REFUSED: floor full")
                else:
                    n = Node(
                        id=state.next_id(),
                        title=title,
                        floor=fl,
                        x=sx,
                    )
                    tengoku_sel = False
                    jigoku_sel = False
                    if read_form_into(n):
                        old_fc = state.floor_count()
                        state.nodes.append(n)
                        adjust_stickers_after_floor_change(state, assets, old_fc)
                        selected_node = n.id
                        if n.elevator != "none":
                            apply_elevator_x(state, n.elevator, n.x, assets, anchor=n)
                        prune_edge_ports(state)
                        set_status(f"Added {n.title} on {floor_label(n.floor)}")
        if button(screen, "updn", Rect(x0 + 140, y, 130, 26), "Update", mouse, click):
            n = state.find_by_id(selected_node) if selected_node else None
            if not n:
                set_status("No node selected.")
            else:
                if read_form_into(n):
                    if n.elevator != "none":
                        apply_elevator_x(state, n.elevator, n.x, assets, anchor=n)
                    set_status(f"Updated {n.title}")
        del_r = Rect(x0 + 280, y, 26, 26)
        pygame.draw.rect(screen, (72, 40, 42), del_r, border_radius=3)
        pygame.draw.rect(screen, (120, 70, 72), del_r, 1, border_radius=3)
        xt = ui_font_b.render("X", True, (210, 160, 160))
        screen.blit(xt, (del_r.x + (del_r.w - xt.get_width()) // 2,
                         del_r.y + (del_r.h - xt.get_height()) // 2))
        if click and del_r.collidepoint(mouse):
            despawn_selected_node()
        y += 36

        pygame.draw.line(screen, (70, 70, 80), (x0, y), (panel.right - 10, y))
        y += 8
        sticker_sec_y = y
        stickers_frozen = hide_stickers or lock_stickers
        sclick = click and not stickers_frozen
        st_col = (180, 200, 255) if not stickers_frozen else (90, 90, 100)
        draw_text(screen, "STICKERS", (x0, y), ui_font_b, st_col)
        _sn = assets.sticker_names
        if _sn:
            pick = _sn[catalog_sel % len(_sn)]
            tw = ui_font_b.size("STICKERS")[0]
            draw_text(screen, " - " + pick, (x0 + tw, y + 2), ui_font_sm, st_col)
        sel_st_title = next((s for s in state.stickers if s.id == selected_sticker), None)
        if sel_st_title is not None:
            draw_text(screen, "Lv:", (panel.right - 168, y + 1), ui_font_sm, st_col)
            field_box(screen, "sticker_level", Rect(panel.right - 146, y - 2, 36, 20), mouse, sclick)
            draw_text(screen, "Am:", (panel.right - 104, y + 1), ui_font_sm, st_col)
            field_box(screen, "sticker_amount", Rect(panel.right - 76, y - 2, 36, 20), mouse, sclick)
        y += 18
        field_box(screen, "sticker_x", Rect(x0, y + 14, 70, 22), mouse, sclick, "X")
        field_box(screen, "sticker_y", Rect(x0 + 80, y + 14, 70, 22), mouse, sclick, "Y")
        sel_st = next((s for s in state.stickers if s.id == selected_sticker), None)
        big_r = Rect(x0 + 234, y + 14, 70, 22)
        if sel_st:
            if button(screen, "bigst", big_r, "Big" if not sel_st.big else "Norm", mouse, sclick):
                sel_st.big = not sel_st.big
                sel_st.tile_x, sel_st.tile_y = clamp_sticker_xy(
                    sel_st.tile_x, sel_st.tile_y, state, assets, sel_st.name, sel_st.big)
                set_status("Sticker enlarged." if sel_st.big else "Sticker normal size.")
        else:
            pygame.draw.rect(screen, (40, 40, 44), big_r, border_radius=3)
            pygame.draw.rect(screen, (80, 80, 80), big_r, 1, border_radius=3)
            ts = ui_font.render("Big", True, (110, 110, 110))
            screen.blit(ts, (big_r.x + (big_r.w - ts.get_width()) // 2,
                             big_r.y + (big_r.h - ts.get_height()) // 2))
        if button(screen, "addst", Rect(x0 + 160, y + 14, 70, 22), "Add", mouse, sclick):
            add_sticker_from_ui()
        dsp = Rect(x0 + 310, y + 14, 26, 22)
        pygame.draw.rect(screen, (72, 40, 42) if not stickers_frozen else (40, 40, 44), dsp, border_radius=3)
        pygame.draw.rect(screen, (120, 70, 72), dsp, 1, border_radius=3)
        xt = ui_font_b.render("X", True, (210, 160, 160) if not stickers_frozen else (110, 90, 90))
        screen.blit(xt, (dsp.x + (dsp.w - xt.get_width()) // 2,
                         dsp.y + (dsp.h - xt.get_height()) // 2))
        if sclick and dsp.collidepoint(mouse):
            despawn_selected_sticker()
        y += 44

        # catalog
        cat_h = max(80, panel.bottom - y - 8)
        cat_rect = Rect(x0, y, 400, cat_h)
        pygame.draw.rect(screen, (24, 24, 28), cat_rect)
        pygame.draw.rect(screen, (80, 80, 90), cat_rect, 1)
        names = assets.sticker_names
        cell = 72
        cols = 5
        header_h = 18
        raw_ent = getattr(assets, "catalog_entries", None) or [("item", n, 0) for n in names]
        vis_ent = []
        hide_below = None
        for ent in raw_ent:
            kind = ent[0]
            depth = ent[2] if len(ent) > 2 else 1
            if kind == "cat":
                if hide_below is not None and depth > hide_below:
                    continue
                hide_below = None
                vis_ent.append(ent)
                key = (ent[3] if len(ent) > 3 else ent[1], depth)
                if key in collapsed_cats:
                    hide_below = depth
            else:
                if hide_below is not None:
                    continue
                vis_ent.append(ent)
        rows = catalog_rows(vis_ent, cols)
        if rows:
            catalog_scroll = clamp(catalog_scroll, 0, max(0, len(rows) - 1))
            ycur = cat_rect.y + 4
            for ri in range(catalog_scroll, len(rows)):
                kind, payload = rows[ri]
                if kind == "cat":
                    if ycur + header_h > cat_rect.bottom:
                        break
                    if isinstance(payload, tuple) and len(payload) >= 3:
                        cname, cdepth, rel = payload[0], payload[1], payload[2]
                    elif isinstance(payload, tuple):
                        cname, cdepth, rel = payload[0], payload[1], payload[0]
                    else:
                        cname, cdepth, rel = payload, 1, str(payload)
                    rel = str(rel).replace("\\", "/")
                    ckey = (rel or cname, cdepth)
                    on = ckey in collapsed_cats
                    cb = Rect(cat_rect.x + 6, ycur + 2, 12, 12)
                    pygame.draw.rect(screen, (70, 70, 40) if on else (36, 36, 42), cb, border_radius=2)
                    pygame.draw.rect(screen, (200, 200, 120) if on else (90, 90, 100), cb, 1, border_radius=2)
                    if on:
                        pygame.draw.line(screen, (220, 220, 140), (cb.x + 3, cb.centery), (cb.right - 3, cb.centery), 2)
                    if sclick and cb.collidepoint(mouse):
                        if on:
                            collapsed_cats.discard(ckey)
                        else:
                            collapsed_cats.add(ckey)
                    draw_text(screen, str(cname), (cat_rect.x + 22, ycur), ui_font_sm, (150, 150, 158))
                    starred = getattr(assets, "starred_folders", set())
                    lit = rel.lower() in {str(s).replace("\\", "/").lower() for s in starred}
                    star_sz = 14
                    star_r = Rect(cat_rect.right - 30, ycur + 1, star_sz, star_sz)
                    cache = catalog_bar.setdefault("star_surfs", {})
                    if "on" not in cache or "off" not in cache:
                        for key, fname in (("on", "Catalog_star_yellow"), ("off", "Catalog_star_gray")):
                            simg = assets.get(fname)
                            if simg is not None:
                                tiny = simg if simg.size == (star_sz, star_sz) else simg.resize(
                                    (star_sz, star_sz), Image.Resampling.LANCZOS)
                                cache[key] = pil_to_surf(tiny)
                    surf = cache.get("on" if lit else "off")
                    if surf is not None:
                        screen.blit(surf, star_r.topleft)
                    else:
                        pygame.draw.rect(screen, (230, 200, 50) if lit else (70, 70, 76), star_r)
                    if click and star_r.collidepoint(mouse):
                        cur = set(getattr(assets, "starred_folders", set()))
                        key = rel.lower()
                        if key in {str(s).lower() for s in cur}:
                            cur = {s for s in cur if str(s).replace("\\", "/").lower() != key}
                        else:
                            cur.add(rel)
                        assets.starred_folders = cur
                        assets.reload_images()
                    pygame.draw.line(screen, (70, 70, 78),
                                     (cat_rect.x + 8, ycur + header_h - 3),
                                     (cat_rect.right - 32, ycur + header_h - 3), 1)
                    ycur += header_h
                    continue
                if ycur + 64 > cat_rect.bottom:
                    break
                for col, name in enumerate(payload):
                    rx = cat_rect.x + 6 + col * cell
                    ry = ycur
                    r = Rect(rx, ry, 64, 64)
                    idx = names.index(name) if name in names else 0
                    on = idx == catalog_sel
                    pygame.draw.rect(screen, (50, 50, 58), r)
                    th = assets.thumbs.get(name)
                    if th is not None:
                        if name not in pg_thumbs:
                            pg_thumbs[name] = pil_to_surf(th.convert("RGBA"))
                        screen.blit(pg_thumbs[name], r)
                    else:
                        draw_text(screen, name[:6], (rx + 4, ry + 24), ui_font_sm)
                    pygame.draw.rect(screen, (255, 255, 255) if on else (90, 90, 100), r, 3 if on else 1)
                    if sclick and r.collidepoint(mouse):
                        catalog_sel = idx
                        selected_sticker = None
                        fields["sticker_level"] = ""
                        fields["sticker_amount"] = ""
                    color = path_dot_color(name)
                    if color and r.collidepoint(mouse) and catalog_rmb is not None:
                        catalog_rmb["name"] = name
                        held = pygame.time.get_ticks() - catalog_rmb["t"]
                        if held >= 2000 and not catalog_rmb.get("cleared"):
                            selected_sticker, ok = clear_path_color(state, color, selected_sticker)
                            catalog_rmb["cleared"] = True
                            set_status(f"Cleared {color} path" if ok else f"No {color} path dots")
                        elif held >= 400:
                            pygame.draw.rect(screen, (180, 50, 50), r, 3)
                ycur += cell
            vis = max(1, (cat_rect.h - 8) // cell)
            max_s = max(0, len(rows) - vis)
            catalog_scroll = clamp(catalog_scroll, 0, max_s)
            bar = Rect(cat_rect.right - 10, cat_rect.y + 2, 8, cat_rect.h - 4)
            catalog_bar["rect"] = bar
            catalog_bar["max"] = max_s
            pygame.draw.rect(screen, (48, 48, 54), bar, border_radius=3)
            if max_s > 0:
                th = max(18, int(bar.h * vis / max(1, len(rows))))
                ty = bar.y + int((bar.h - th) * catalog_scroll / max_s)
                thumb = Rect(bar.x, ty, bar.w, th)
                pygame.draw.rect(screen, (140, 140, 150), thumb, border_radius=3)
                if sclick and bar.collidepoint(mouse):
                    catalog_dragging = True
                    t = (mouse[1] - bar.y) / max(1, bar.h)
                    catalog_scroll = int(clamp(t * (max_s + 1), 0, max_s))

        if stickers_frozen:
            ov = pygame.Surface((panel.w, max(1, panel.bottom - sticker_sec_y)), pygame.SRCALPHA)
            ov.fill((16, 16, 20, 160))
            screen.blit(ov, (panel.x, sticker_sec_y))

        if status_at and pygame.time.get_ticks() - status_at > 10000:
            status = "Ready."
            status_color = (200, 200, 160)
            status_at = 0
        # status bar
        pygame.draw.rect(screen, (16, 16, 18), Rect(0, sh - 28, sw, 28))
        draw_text(screen, status, (8, sh - 22), ui_font_sm, status_color)
        now_ui = pygame.time.get_ticks()
        goku_r = Rect(sw - 406, sh - 24, 110, 20)
        flip_r = Rect(sw - 292, sh - 24, 68, 20)
        thumb_r = Rect(sw - 220, sh - 24, 88, 20)
        update_r = Rect(sw - 128, sh - 24, 66, 20)
        keys_r = Rect(sw - 58, sh - 24, 50, 20)
        if button(screen, "gokus", goku_r, "Connect gokus", mouse, click):
            set_status(connect_goku_floors(state))
        if button(screen, "flipbg", flip_r, "Flip BG", mouse, click):
            flip_bg = not flip_bg
            set_status("Floor stripes flipped." if flip_bg else "Floor stripes default.")
        on_cd = now_ui < thumb_cd_until
        if on_cd:
            pygame.draw.rect(screen, (40, 40, 44), thumb_r, border_radius=3)
            pygame.draw.rect(screen, (80, 80, 80), thumb_r, 1, border_radius=3)
            ts = ui_font_sm.render("Thumbnail", True, (110, 110, 110))
            screen.blit(ts, (thumb_r.x + (thumb_r.w - ts.get_width()) // 2,
                             thumb_r.y + (thumb_r.h - ts.get_height()) // 2))
        elif button(screen, "thumbs", thumb_r, "Thumbnail", mouse, click):
            ensure_user_asset_folders()
            assets.reload_images()
            assets.sync_thumbnails(force=True)
            pg_thumbs.clear()
            catalog_bar.pop("star_surfs", None)
            thumb_cd_until = pygame.time.get_ticks() + 5000
            set_status("Catalog thumbnails updated.")
        if button(screen, "update", update_r, "Update", mouse, click):
            start_update()
        if button(screen, "keys", keys_r, "Keys", mouse, click):
            helper = os.path.join(bundle_dir(), "shortcuts_editor.py")
            if not os.path.isfile(helper):
                helper = os.path.join(SCRIPT_DIR, "shortcuts_editor.py")
            try:
                if getattr(sys, "frozen", False):
                    proc = subprocess.Popen([sys.executable, "--shortcuts"], cwd=SCRIPT_DIR)
                elif os.path.isfile(helper):
                    proc = subprocess.Popen([sys.executable, helper], cwd=SCRIPT_DIR)
                else:
                    set_status("REFUSED: shortcuts_editor.py not found")
                    proc = None
                if proc is not None:
                    while proc.poll() is None:
                        pygame.event.clear()
                        pygame.event.pump()
                        clock.tick(30)
                    shortcuts = load_shortcuts()
                    set_status("Shortcuts reloaded.")
            except Exception as e:
                set_status(f"Shortcuts editor failed: {e}")

        if click and active_field:
            fr = buttons.get(f"field_{active_field}")
            on_it = bool(fr and hasattr(fr, "collidepoint") and fr.collidepoint(mouse))
            if not on_it:
                commit_field(active_field)
                active_field = None
                selecting_field = None

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()


def render_headless(out_png: str, out_json: str = ""):
    ensure_user_asset_folders()
    assets = AssetStore()
    assets.load_json(DEFAULT_JSON)
    renderer = MapRenderer(assets)
    state = MapState()
    boot = placeholder_json_path()
    if boot:
        try:
            with open(boot, "r", encoding="utf-8") as f:
                state.load_dict(json.load(f), assets)
        except Exception:
            state.seed_default()
    else:
        state.seed_default()
    renderer.export_png(state, out_png)
    print("wrote", out_png)


def main():
    if "--shortcuts" in sys.argv:
        import shortcuts_editor
        raise SystemExit(shortcuts_editor.run())
    if "--render-popup" in sys.argv:
        import render_popup
        raise SystemExit(render_popup.run(sys.argv[1:]))
    ensure_user_asset_folders()
    if "--render-test" in sys.argv:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        out = os.path.join(SCRIPT_DIR, "Placeholder.webp")
        js = os.path.join(SCRIPT_DIR, "Placeholder.json")
        render_headless(out, js)
        return
    try:
        run_editor()
    except Exception as e:
        import traceback
        print("Editor failed to open a window:", e)
        traceback.print_exc()
        print("Generating default map instead.")
        render_headless(os.path.join(SCRIPT_DIR, "Placeholder.webp"),
                        os.path.join(SCRIPT_DIR, "Placeholder.json"))


if __name__ == "__main__":
    main()