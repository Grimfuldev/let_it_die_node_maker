#!/usr/bin/env python3
"""Convert every PNG in a folder (and subfolders) to WebP quality 100 and replace the PNG."""

import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

try:
    from PIL import Image
except ImportError:
    raise SystemExit("Pillow is required. Install it with: pip install Pillow")


def find_pngs(root: Path) -> list[Path]:
    """PNG files under root only. Symlinks that resolve outside root are skipped."""
    root = root.resolve()
    found = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() != ".png":
            continue
        try:
            resolved = path.resolve()
        except OSError:
            continue
        if root == resolved or root in resolved.parents:
            found.append(path)
    return sorted(found)


def convert_one(png_path: Path) -> Path:
    webp_path = png_path.with_suffix(".webp")
    with Image.open(png_path) as img:
        # Preserve alpha. quality=100 is the highest WebP lossy setting.
        img.save(webp_path, "WEBP", quality=100, method=6)
    png_path.unlink()
    return webp_path


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("PNG to WebP")
        self.resizable(False, False)
        self.configure(padx=24, pady=20)
        self.root_folder: Path | None = None
        self.pngs: list[Path] = []

        tk.Label(
            self,
            text="Import a folder, then press Start.\n"
            "Only PNGs inside that folder and its subfolders are replaced\n"
            "with a WebP of the same name at quality 100.",
            justify="left",
        ).pack(anchor="w")

        self.import_button = tk.Button(
            self,
            text="Import folder",
            command=self.import_folder,
            width=22,
            pady=8,
        )
        self.import_button.pack(pady=(16, 6))

        self.start_button = tk.Button(
            self,
            text="Start",
            command=self.start,
            width=22,
            pady=8,
            state="disabled",
        )
        self.start_button.pack(pady=(0, 10))

        self.status = tk.StringVar(value="No folder selected.")
        tk.Label(self, textvariable=self.status, wraplength=380, justify="left").pack(
            anchor="w"
        )

    def import_folder(self) -> None:
        folder = filedialog.askdirectory(title="Select folder to convert")
        if not folder:
            return
        root = Path(folder).resolve()
        pngs = find_pngs(root)
        self.root_folder = root
        self.pngs = pngs
        if not pngs:
            self.start_button.configure(state="disabled")
            self.status.set(f"No PNG files in {root}")
            messagebox.showinfo("PNG to WebP", "No PNG files found in that folder.")
            return
        self.start_button.configure(state="normal")
        self.status.set(f"{len(pngs)} PNG file(s) in {root}\nPress Start to replace them.")

    def start(self) -> None:
        if not self.root_folder or not self.pngs:
            return
        root = self.root_folder
        pngs = list(self.pngs)
        if not messagebox.askyesno(
            "Replace PNGs?",
            f"Found {len(pngs)} PNG file(s) under:\n{root}\n\n"
            "Nothing outside this folder is touched.\n\n"
            "Each file becomes a .webp (quality 100) with the same name, "
            "and the original .png is deleted.",
        ):
            self.status.set("Cancelled.")
            return
        self.import_button.configure(state="disabled")
        self.start_button.configure(state="disabled")
        self.status.set(f"Converting 0 / {len(pngs)}…")
        threading.Thread(target=self._convert, args=(pngs,), daemon=True).start()

    def _convert(self, pngs: list[Path]) -> None:
        done = 0
        failed: list[str] = []
        for png in pngs:
            try:
                convert_one(png)
            except Exception as exc:  # keep going so one bad file doesn't stop the batch
                failed.append(f"{png.name}: {exc}")
            done += 1
            self.after(0, self.status.set, f"Converting {done} / {len(pngs)}…")
        self.after(0, self._finish, len(pngs), failed)

    def _finish(self, total: int, failed: list[str]) -> None:
        self.import_button.configure(state="normal")
        self.pngs = []
        self.start_button.configure(state="disabled")
        ok = total - len(failed)
        if failed:
            detail = "\n".join(failed[:8])
            extra = "" if len(failed) <= 8 else f"\n…and {len(failed) - 8} more"
            self.status.set(f"Done. {ok} converted, {len(failed)} failed.")
            messagebox.showwarning(
                "PNG to WebP",
                f"Converted {ok} of {total}.\n\nFailed:\n{detail}{extra}",
            )
        else:
            self.status.set(f"Done. Replaced {ok} PNG file(s) with WebP.")
            messagebox.showinfo("PNG to WebP", f"Replaced {ok} PNG file(s) with WebP.")


if __name__ == "__main__":
    App().mainloop()
