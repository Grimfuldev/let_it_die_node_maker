#!/usr/bin/env python3
"""Render popup: WebP quality preset and export without freezing the editor."""
from __future__ import annotations

import argparse
import json
import sys
import threading

import os
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True

from map_core import (
    AssetStore, MapRenderer, MapState, DEFAULT_JSON,
    apply_editor_chrome, find_ui_asset, set_windows_app_id, ensure_user_asset_folders,
    ASSET_BG,
)

PRESETS = (("Low", 40), ("Medium", 80), ("Full", 100))


def parse_args(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--json", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--hide-stickers", action="store_true")
    p.add_argument("--hide-paths", action="store_true")
    p.add_argument("--flip-bg", action="store_true")
    args, _ = p.parse_known_args(argv)
    return args


def clicked_outside(hwnd, prev_btns, ignore_until):
    if sys.platform != "win32" or not hwnd:
        return False, prev_btns
    import ctypes
    class POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
    user32 = ctypes.windll.user32
    down = 0
    if user32.GetAsyncKeyState(0x01) & 0x8000:
        down |= 1
    if user32.GetAsyncKeyState(0x02) & 0x8000:
        down |= 2
    if user32.GetAsyncKeyState(0x04) & 0x8000:
        down |= 4
    fresh = down & ~prev_btns
    import pygame
    if not fresh or pygame.time.get_ticks() < ignore_until:
        return False, down
    pt = POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    under = user32.WindowFromPoint(pt)
    return bool(under) and int(under) != int(hwnd), down


def run(argv=None) -> int:
    import pygame
    from pygame import Rect
    from PIL import Image

    args = parse_args(argv)
    set_windows_app_id()
    pygame.init()
    W, H = 320, 210
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Render")
    apply_editor_chrome(screen)
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("segoeui,arial", 16)
    font_b = pygame.font.SysFont("segoeui,arial", 17, bold=True)
    font_sm = pygame.font.SysFont("segoeui,arial", 13)

    bg_surf = None
    bg = find_ui_asset(ASSET_BG)
    if bg:
        try:
            im = Image.open(bg).convert("RGBA").resize((W, H), Image.Resampling.LANCZOS)
            bg_surf = pygame.image.frombuffer(im.tobytes(), im.size, "RGBA")
        except Exception:
            bg_surf = None

    def load_ui_image(*names, size=(64, 64)):
        path = find_ui_asset(*names)
        if not path:
            return None
        try:
            im = Image.open(path).convert("RGBA")
            im = im.resize(size, Image.Resampling.LANCZOS)
            return pygame.image.frombuffer(im.tobytes(), im.size, "RGBA")
        except Exception:
            return None

    ICON = 64
    spin = load_ui_image("Rendering.webp", "Rendering.png", size=(ICON, ICON))
    done_img = load_ui_image("Rendering_end.webp", "Rendering_end.png", size=(ICON, ICON))
    err_img = pygame.transform.flip(done_img, False, True) if done_img is not None else None

    quality = 80
    status = "Ready."
    phase = "idle"
    result = {"ok": None, "path": "", "err": ""}
    angle = 0
    success_at = 0
    close_when_done = False

    hwnd = None
    prev_btns = 7
    ignore_until = pygame.time.get_ticks() + 250
    if sys.platform == "win32":
        try:
            hwnd = pygame.display.get_wm_info().get("window")
        except Exception:
            hwnd = None

    def start_render():
        nonlocal phase, status
        phase = "rendering"
        status = "Rendering..."
        q = quality

        def work():
            try:
                ensure_user_asset_folders()
                assets = AssetStore()
                assets.load_json(DEFAULT_JSON)
                state = MapState()
                with open(args.json, "r", encoding="utf-8") as f:
                    state.load_dict(json.load(f), assets)
                rend = MapRenderer(assets)
                out = rend.export_png(
                    state, args.out,
                    hide_stickers=args.hide_stickers,
                    hide_paths=args.hide_paths,
                    flip_bg=args.flip_bg,
                    quality=q,
                )
                result["ok"] = True
                result["path"] = out
            except Exception as e:
                result["ok"] = False
                result["err"] = str(e)

        threading.Thread(target=work, daemon=True).start()

    running = True
    exit_code = 2
    while running:
        click = False
        mouse = pygame.mouse.get_pos()
        lost, prev_btns = clicked_outside(hwnd, prev_btns, ignore_until)
        if lost:
            if phase == "rendering":
                close_when_done = True
            else:
                running = False
                break

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                if phase == "rendering":
                    close_when_done = True
                else:
                    running = False
            elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                click = True

        if phase == "rendering" and result["ok"] is True:
            phase = "success"
            status = "Done."
            success_at = pygame.time.get_ticks()
            exit_code = 0
        elif phase == "rendering" and result["ok"] is False:
            phase = "error"
            status = "Error"
            success_at = pygame.time.get_ticks()
            exit_code = 1

        if phase in ("success", "error") and close_when_done:
            running = False
            break
        if phase in ("success", "error") and pygame.time.get_ticks() - success_at >= 3000:
            running = False
            break

        if bg_surf:
            screen.blit(bg_surf, (0, 0))
        else:
            screen.fill((22, 22, 26))

        screen.blit(font_b.render("Render map", True, (180, 200, 255)), (14, 10))
        busy = phase in ("rendering", "success", "error")

        x = 14
        for label, qv in PRESETS:
            br = Rect(x, 38, 92, 24)
            on = quality == qv
            pygame.draw.rect(screen, (50, 50, 58), br, border_radius=3)
            border = (255, 255, 255) if on else (90, 90, 100)
            pygame.draw.rect(screen, border, br, 2 if on else 1, border_radius=3)
            ts = font_sm.render(f"{label} {qv}", True, (230, 230, 230))
            screen.blit(ts, (br.x + (br.w - ts.get_width()) // 2, br.y + 4))
            if click and not busy and br.collidepoint(mouse):
                quality = qv
            x = br.right + 8

        cx, cy = W // 2, 108
        if phase == "rendering" and spin:
            angle = (angle + 5) % 360
            rot = pygame.transform.rotate(spin, -angle)
            screen.blit(rot, rot.get_rect(center=(cx, cy)))
        elif phase == "success" and done_img:
            screen.blit(done_img, done_img.get_rect(center=(cx, cy)))
        elif phase == "error" and err_img:
            screen.blit(err_img, err_img.get_rect(center=(cx, cy)))
        elif phase == "rendering":
            pygame.draw.circle(screen, (80, 80, 90), (cx, cy), 22, 3)

        col = (120, 220, 140) if phase == "success" else ((220, 90, 90) if phase == "error" else (220, 220, 160))
        st = font.render(status, True, col)
        screen.blit(st, (cx - st.get_width() // 2, 148))

        rr = Rect(16, H - 38, 110, 26)
        cr = Rect(W - 126, H - 38, 110, 26)
        pygame.draw.rect(screen, (40, 40, 44) if busy else (48, 70, 48), rr, border_radius=3)
        pygame.draw.rect(screen, (80, 80, 80) if busy else (140, 200, 140), rr, 1, border_radius=3)
        screen.blit(font.render("Render", True, (110, 110, 110) if busy else (230, 230, 230)),
                    (rr.x + 24, rr.y + 3))
        pygame.draw.rect(screen, (40, 40, 44) if busy else (48, 48, 54), cr, border_radius=3)
        pygame.draw.rect(screen, (80, 80, 80) if busy else (140, 140, 145), cr, 1, border_radius=3)
        screen.blit(font.render("Cancel", True, (110, 110, 110) if busy else (230, 230, 230)),
                    (cr.x + 24, cr.y + 3))
        if click and not busy and rr.collidepoint(mouse):
            start_render()
        if click and not busy and cr.collidepoint(mouse):
            running = False
            exit_code = 2

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    return exit_code


if __name__ == "__main__":
    raise SystemExit(run(sys.argv[1:]))