from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True

from PIL import Image, ImageDraw, ImageFont

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

GRID = 15
MAP_W = 2090
FLOOR_H = 175
NODE_W, NODE_H = 228, 90
CONNECT_W, CONNECT_H = 15, 22
CONNECT_OVERLAP = 8
STAR_DRAW = 36
STAR_NUM = 16
ELEV_S = 35
FLOOR_BOX = (60, 28)

VERSION = "v0.1"
WINDOW_TITLE = f"Leeeeet It Die Node Maker {VERSION}"

def app_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def bundle_dir() -> str:
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", app_dir())
    return app_dir()


SCRIPT_DIR = app_dir()
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

def _dir(*parts: str) -> str:
    return os.path.join(*parts)


def resolve_data_dir(name: str) -> str:
    for root in (SCRIPT_DIR, bundle_dir()):
        p = _dir(root, name)
        if os.path.isdir(p):
            return p
    return _dir(SCRIPT_DIR, name)


def resolve_bundled_dir(name: str) -> str:
    for root in (bundle_dir(), SCRIPT_DIR):
        p = _dir(root, name)
        if os.path.isdir(p):
            return p
    return _dir(bundle_dir(), name)


GRID_ASSETS_DIR = resolve_data_dir("Grid_assets")
STICKER_ASSETS_DIR = resolve_data_dir("Sticker_assets")
THUMBS_DIR = _dir(STICKER_ASSETS_DIR, "catalog_thumbnails")
UI_ASSETS_DIR = resolve_data_dir("UI_assets")
UI_ASSETS_BUNDLE = _dir(bundle_dir(), "UI_assets")
FALLBACK_ASSETS_DIR = resolve_bundled_dir("Fallback_folder_assets")
FALLBACK_GRID_DIR = _dir(FALLBACK_ASSETS_DIR, "Grid_assets")
FALLBACK_STICKER_DIR = _dir(FALLBACK_ASSETS_DIR, "Sticker_assets")
DEFAULT_JSON = _dir(SCRIPT_DIR, "lid_map_images.json")


def placeholder_json_path() -> str:
    for p in (
        _dir(SCRIPT_DIR, "Placeholder.json"),
        _dir(FALLBACK_ASSETS_DIR, "Placeholder.json"),
        _dir(bundle_dir(), "Fallback_folder_assets", "Placeholder.json"),
    ):
        if p and os.path.isfile(p):
            return p
    return ""


ASSET_CURSOR = "let it die cursor.webp"
ASSET_BG = "UI background.webp"
ASSET_ICON = "uncle glasses ready.webp"

def _first_existing(paths):
    for p in paths:
        if p and os.path.isfile(p):
            return p
    return None


def resolve_fonts():
    """Find TTF files on Windows/Linux/macOS, or next to this script."""
    windir = os.environ.get("WINDIR", r"C:\Windows")
    win_fonts = os.path.join(windir, "Fonts")
    candidates_reg = [
        os.path.join(SCRIPT_DIR, "DejaVuSans.ttf"),
        os.path.join(SCRIPT_DIR, "arial.ttf"),
        os.path.join(SCRIPT_DIR, "fonts", "DejaVuSans.ttf"),
        os.path.join(win_fonts, "arial.ttf"),
        os.path.join(win_fonts, "segoeui.ttf"),
        os.path.join(win_fonts, "tahoma.ttf"),
        os.path.join(win_fonts, "calibri.ttf"),
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/Library/Fonts/Arial.ttf",
    ]
    candidates_bold = [
        os.path.join(SCRIPT_DIR, "DejaVuSans-Bold.ttf"),
        os.path.join(SCRIPT_DIR, "arialbd.ttf"),
        os.path.join(SCRIPT_DIR, "fonts", "DejaVuSans-Bold.ttf"),
        os.path.join(win_fonts, "arialbd.ttf"),
        os.path.join(win_fonts, "segoeuib.ttf"),
        os.path.join(win_fonts, "tahomabd.ttf"),
        os.path.join(win_fonts, "calibrib.ttf"),
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
        "/Library/Fonts/Arial Bold.ttf",
    ]
    regular = _first_existing(candidates_reg)
    bold = _first_existing(candidates_bold) or regular
    return regular, bold


FONT_PATH, FONT_BOLD = resolve_fonts()

PORT_KEYS = [
    "top_left",
    "top_mid",
    "top_right",
    "und_left",
    "und_mid",
    "und_right",
]
EDGE_TARGET = "__EDGE__"

CONN_COLORS = {
    "orange": (0xE5, 0x78, 0x0E),
    "cyan": (0x02, 0xF2, 0xC4),
    "purple": (0x8B, 0x66, 0xF2),
    "green": (0x68, 0xEF, 0x39),
    "blue": (0x00, 0x42, 0xFC),
    "magenta": (0xED, 0x23, 0x86),
    "pink": (0xDF, 0x9E, 0xF2),
}

ELEVATOR_KINDS = ["none", "blue", "green", "purple", "pink", "brown"]
ELEVATOR_HEX = {
    "blue": (0x50, 0x4E, 0x7D),
    "green": (0x43, 0x5F, 0x62),
    "purple": (0x60, 0x52, 0x88),
    "pink": (0x6C, 0x45, 0x66),
    "brown": (0x68, 0x67, 0x45),
}

MATERIALS = ["Iron", "Aluminum", "Copper", "Wood", "Oil", "Fabric", "None", "Empty", "ALL"]
MATERIAL_LABELS = {"ALL": "All", "Empty": "Empty"}
COLOR_ORDER = ["cyan", "blue", "purple", "orange", "green", "pink"]
GATES = ["open", "closed-gate", "gate-up", "gate-down"]
GATE_LABELS = {
    "none": "open",
    "open": "open",
    "open-gate": "open",
    "closed-gate": "closed",
    "gate-up": "gate-up",
    "gate-down": "gate-down",
}

FOOTER = "Make your own Let It Die maps: github.com/Grimfuldev/let_it_die_node_maker"

PATH_DOT_COLORS = ["Red_Path", "Orange_Path", "White_Path", "Cyan_Path", "Green_Path"]
PATH_DOT_RGB = {
    "Red_Path": (210, 48, 48),
    "Orange_Path": (230, 140, 36),
    "White_Path": (236, 236, 240),
    "Cyan_Path": (40, 210, 210),
    "Green_Path": (56, 190, 70),
}
PATH_ROUTE_DIR = "Path_route"
PORT_LINE_W = 3.8
PATH_LINE_W = 3
SCROLL_W = 14


def floor_label(idx: int) -> str:
    idx = int(idx)
    if idx == 0:
        return "B1"
    return f"{idx}F"


def parse_floor_text(raw) -> Optional[int]:
    t = (raw or "").strip().upper().replace(" ", "")
    if not t:
        return None
    if t in ("B1", "B-1", "B01", "0F"):
        return 0
    if t.endswith("F") and t[:-1].lstrip("-").isdigit():
        try:
            return int(t[:-1])
        except ValueError:
            return None
    try:
        return int(t)
    except ValueError:
        return None


def clamp(v, a, b):
    return max(a, min(b, v))


def snap(v: int, g: int = GRID) -> int:
    return int(round(v / g) * g)


def _tk_set_icon(root) -> None:
    """Glasses on import, export, and folder dialogs. Tk cannot load webp itself."""
    try:
        src = find_ui_asset(ASSET_ICON)
        if not src:
            return
        import tempfile
        from PIL import Image
        im = Image.open(src).convert("RGBA")
        tmp = os.path.join(tempfile.gettempdir(), "lid_node_maker_glasses.ico")
        im.resize((32, 32), Image.Resampling.LANCZOS).save(tmp, format="ICO", sizes=[(32, 32)])
        root.iconbitmap(tmp)
        root._lid_icon = tmp
    except Exception:
        pass


def native_file_dialog(mode="open", title="Open", filetypes=None, initialdir=None, initialfile=None):
    """Windows-friendly file/folder popup. mode: open | save | dir."""
    initialdir = initialdir or SCRIPT_DIR
    filetypes = filetypes or [("JSON", "*.json"), ("All files", "*.*")]
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        try:
            root.wm_attributes("-topmost", 1)
        except Exception:
            pass
        _tk_set_icon(root)
        if mode == "dir":
            path = filedialog.askdirectory(parent=root, title=title, initialdir=initialdir)
        elif mode == "save":
            path = filedialog.asksaveasfilename(
                parent=root, title=title, initialdir=initialdir, initialfile=initialfile or "",
                defaultextension=".json", filetypes=filetypes,
            )
        else:
            path = filedialog.askopenfilename(
                parent=root, title=title, initialdir=initialdir, filetypes=filetypes,
            )
        root.destroy()
        return path or ""
    except Exception:
        return ""


SHORTCUTS_PATH = _dir(SCRIPT_DIR, "Shortcuts.ini")

PORT_HOTKEY_ACTIONS = {
    "port_top_left": "top_left",
    "port_top_mid": "top_mid",
    "port_top_right": "top_right",
    "port_und_left": "und_left",
    "port_und_mid": "und_mid",
    "port_und_right": "und_right",
}


def load_shortcuts(path: str = "") -> Dict[str, int]:
    """Map action name -> pygame key constant. Empty if the ini is missing."""
    path = path or SHORTCUTS_PATH
    if not path or not os.path.isfile(path):
        bundled = os.path.join(bundle_dir(), "Shortcuts.ini")
        path = bundled if os.path.isfile(bundled) else path
    out: Dict[str, int] = {}
    if not path or not os.path.isfile(path):
        return out
    try:
        import pygame
        import configparser
        cfg = configparser.ConfigParser()
        cfg.read(path, encoding="utf-8")
        sec = cfg["shortcuts"] if cfg.has_section("shortcuts") else cfg[cfg.default_section]
        for action, raw in sec.items():
            name = str(raw).strip().upper().replace(" ", "")
            if not name:
                continue
            key = getattr(pygame, "K_" + name, None)
            if key is None:
                key = getattr(pygame, "K_" + name.lower(), None)
            if key is not None:
                out[action.lower()] = int(key)
    except Exception:
        return {}
    return out


def native_yes_no(title: str, message: str) -> bool:
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        try:
            root.wm_attributes("-topmost", 1)
        except Exception:
            pass
        _tk_set_icon(root)
        ans = messagebox.askyesno(title, message)
        root.destroy()
        return bool(ans)
    except Exception:
        return False


def load_font(size: int, bold: bool = False):
    path = FONT_BOLD if bold else FONT_PATH
    if path:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            pass
    try:
        return ImageFont.truetype("arial.ttf", size)
    except Exception:
        return ImageFont.load_default()


# ---------------------------------------------------------------------------
# Asset folders (recursive)
# ---------------------------------------------------------------------------

IGNORE_ASSET_DIRS = {"fallback", "catalog_thumbnails", "__pycache__"}

def walk_sticker_catalog(root: str, starred: Optional[set] = None) -> Tuple[List[tuple], List[str]]:
    """DFS: folder title, then PNGs in that folder, then child folders.
    Starred folders (rel path) sort first among siblings, then A–Z."""
    entries: List[tuple] = []
    names: List[str] = []
    starred = {str(s).replace("\\", "/").lower() for s in (starred or set())}

    def walk(folder: str, depth: int, rel: str):
        if not folder or not os.path.isdir(folder):
            return
        try:
            kids = os.listdir(folder)
        except OSError:
            return
        files, dirs = [], []
        for fn in kids:
            if fn.lower() in IGNORE_ASSET_DIRS:
                continue
            p = os.path.join(folder, fn)
            if os.path.isdir(p):
                dirs.append((fn, p))
            elif fn.lower().endswith((".png", ".webp")):
                files.append((os.path.splitext(fn)[0], p, 0 if fn.lower().endswith(".webp") else 1))
        best = {}
        for name, path, rank in files:
            prev = best.get(name.lower())
            if prev is None or rank < prev[0]:
                best[name.lower()] = (rank, name, path)
        files = [(name, path) for _rank, name, path in best.values()]
        files.sort(key=lambda t: t[0].lower())
        dirs.sort(key=lambda t: (
            0 if ((rel + "/" + t[0] if rel else t[0]).replace("\\", "/").lower() in starred) else 1,
            t[0].lower(),
        ))
        if depth > 0:
            entries.append(("cat", os.path.basename(folder), depth, rel))
        for name, _p in files:
            entries.append(("item", name, depth, rel))
            names.append(name)
        for fn, p in dirs:
            child = fn if not rel else rel + "/" + fn
            walk(p, depth + 1, child.replace("\\", "/"))

    walk(root, 0, "")
    return entries, names


def catalog_rows(entries: List[Tuple[str, str]], cols: int = 5) -> List[Tuple[str, object]]:
    rows: List[Tuple[str, object]] = []
    bucket: List[str] = []

    def flush():
        if bucket:
            rows.append(("items", list(bucket)))
            bucket.clear()

    for ent in entries:
        kind = ent[0]
        val = ent[1]
        depth = ent[2] if len(ent) > 2 else 1
        if kind == "cat":
            flush()
            rel = ent[3] if len(ent) > 3 else val
            rows.append(("cat", (val, depth, rel)))
        else:
            bucket.append(val)
            if len(bucket) >= cols:
                flush()
    flush()
    return rows


def scan_png_tree(folder: str, skip_fallback: bool = True) -> Dict[str, str]:
    """Map basename -> path. Case-insensitive keys. Skips Fallback/thumbs."""
    out: Dict[str, str] = {}
    if not folder or not os.path.isdir(folder):
        return out
    for root, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if d.lower() not in IGNORE_ASSET_DIRS]
        if skip_fallback and "fallback" in os.path.normcase(root).split(os.sep):
            continue
        for fn in files:
            low = fn.lower()
            if low.endswith(".webp"):
                rank = 0
            elif low.endswith(".png"):
                rank = 1
            else:
                continue
            key = os.path.splitext(fn)[0]
            path = os.path.join(root, fn)
            prev = out.get(key.lower())
            if prev and prev[0] <= rank:
                continue
            out[key.lower()] = (rank, path)
            out[key] = (rank, path)
    flat = {}
    for key, val in out.items():
        flat[key] = val[1]
    return flat


def lookup_png(index: Dict[str, str], *names: str) -> str:
    for n in names:
        if not n:
            continue
        p = index.get(n) or index.get(n.lower())
        if p and os.path.isfile(p):
            return p
    return ""


def star_count(stars: str) -> int:
    s = (stars or "").strip()
    if s.isdigit():
        return max(1, int(s))
    return 1


def material_file_names(kind: str, stars: str):
    k = kind or "None"
    s = (stars or "").strip()
    names = []
    if not s:
        names += [f"{k}_stack", f"{k.lower()}_stack", f"{k}_Stack"]
        names += [f"{k}_1", f"{k.lower()}_1"]
    else:
        n = star_count(s)
        names += [f"{k}_{n}", f"{k.lower()}_{n}", f"{k}_{n}".title()]
    names += [k, k.lower()]
    return tuple(names)


def elevator_file_names(kind: str):
    return (f"Elevator_{kind}", f"elevator_{kind}", kind, kind.capitalize())


def _copy_missing_tree(src: str, dest: str) -> None:
    """Copy files from src into dest. Never overwrite an existing dest file."""
    if not src or not os.path.isdir(src):
        return
    os.makedirs(dest, exist_ok=True)
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d.lower() not in IGNORE_ASSET_DIRS]
        rel = os.path.relpath(root, src)
        out_dir = dest if rel in (".", "") else os.path.join(dest, rel)
        os.makedirs(out_dir, exist_ok=True)
        for fn in files:
            dst = os.path.join(out_dir, fn)
            if os.path.isfile(dst):
                continue
            src_f = os.path.join(root, fn)
            try:
                shutil.copy2(src_f, dst)
            except Exception:
                pass


def ensure_user_asset_folders():
    os.makedirs(GRID_ASSETS_DIR, exist_ok=True)
    os.makedirs(STICKER_ASSETS_DIR, exist_ok=True)
    os.makedirs(THUMBS_DIR, exist_ok=True)
    _copy_missing_tree(FALLBACK_GRID_DIR, GRID_ASSETS_DIR)
    _copy_missing_tree(FALLBACK_STICKER_DIR, STICKER_ASSETS_DIR)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

def blank_ports() -> Dict[str, dict]:
    return {
        k: {"target": "", "color": "cyan", "gate": "none"}
        for k in PORT_KEYS
    }


@dataclass
class Node:
    id: str
    title: str
    floor: int
    x: int  # world px, top-left, snapped
    material: str = "Empty"
    stars: str = ""
    elevator: str = "none"
    elevator_a: str = ""
    elevator_b: str = ""
    roof: bool = False
    elev_dx: int = 0
    mat_right: bool = False
    tengoku: bool = False
    jigoku: bool = False
    ports: Dict[str, dict] = field(default_factory=blank_ports)

    def rect(self) -> Tuple[int, int, int, int]:
        return (self.x, 0, NODE_W, NODE_H)  # y filled by renderer via floor

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "floor": self.floor,
            "x": self.x,
            "material": self.material,
            "stars": self.stars,
            "elevator": self.elevator,
            "elevator_a": self.elevator_a,
            "elevator_b": self.elevator_b,
            "roof": bool(self.roof),
            "elev_dx": int(self.elev_dx),
            "mat_right": bool(self.mat_right),
            "tengoku": bool(self.tengoku),
            "jigoku": bool(self.jigoku),
            "ports": self.ports,
        }

    @staticmethod
    def from_dict(d: dict) -> "Node":
        ports = blank_ports()
        src = d.get("ports") or {}
        for k in PORT_KEYS:
            if k in src:
                ports[k] = {
                    "target": str(src[k].get("target", "")),
                    "color": src[k].get("color", "cyan"),
                    "gate": src[k].get("gate", "none"),
                }
        return Node(
            id=d.get("id") or d.get("title") or "node",
            title=d.get("title", "NODE"),
            floor=int(d.get("floor", 0)),
            x=int(d.get("x", 0)),
            material=d.get("material", "Empty"),
            stars=str(d.get("stars", "")),
            elevator=d.get("elevator", "none"),
            elevator_a=d.get("elevator_a", ""),
            elevator_b=d.get("elevator_b", ""),
            roof=bool(d.get("roof", False)),
            elev_dx=int(d.get("elev_dx", 0)),
            mat_right=bool(d.get("mat_right", False)),
            tengoku=bool(d.get("tengoku", False)),
            jigoku=bool(d.get("jigoku", False)),
            ports=ports,
        )


def badge_text(raw) -> str:
    t = "".join(ch for ch in str(raw or "") if ch.isalnum())[:2]
    if t in ("", "0"):
        return ""
    return t


@dataclass
class Sticker:
    id: str
    name: str
    tile_x: int
    tile_y: int
    big: bool = False
    level: str = ""
    amount: str = ""

    def to_dict(self) -> dict:
        d = {
            "id": self.id,
            "name": self.name,
            "x": self.tile_x,
            "y": self.tile_y,
        }
        if self.big:
            d["big"] = True
        lv = badge_text(self.level)
        am = badge_text(self.amount)
        if lv:
            d["level"] = lv
        if am:
            d["amount"] = am
        return d

    @staticmethod
    def from_dict(d: dict) -> "Sticker":
        return Sticker(
            id=d.get("id", d.get("name", "sticker")),
            name=d.get("name", ""),
            tile_x=int(d.get("x", 0)),
            tile_y=int(d.get("y", 0)),
            big=bool(d.get("big", False)),
            level=badge_text(d.get("level", "")),
            amount=badge_text(d.get("amount", "")),
        )


class MapState:
    def __init__(self):
        self.name = "Placeholder"
        self.nodes: List[Node] = []
        self.stickers: List[Sticker] = []
        self.path_routes: Dict[str, dict] = blank_path_routes()
        self.uid = 1
        self.ui: dict = {}

    def next_id(self, prefix="n") -> str:
        self.uid += 1
        return f"{prefix}{self.uid}"

    def max_floor(self) -> int:
        if not self.nodes:
            return 0
        return max(n.floor for n in self.nodes)

    def min_floor(self) -> int:
        if not self.nodes:
            return 0
        return min(n.floor for n in self.nodes)

    def floor_count(self) -> int:
        if not self.nodes:
            return 2
        return max(1, self.max_floor() - self.min_floor() + 1)

    def layout_floor(self, floor: int) -> int:
        return int(floor) - self.min_floor()

    def find_by_title(self, title: str) -> Optional[Node]:
        t = (title or "").strip().lower()
        if not t:
            return None
        for n in self.nodes:
            if n.title.strip().lower() == t:
                return n
        return None

    def find_by_id(self, nid: str) -> Optional[Node]:
        for n in self.nodes:
            if n.id == nid:
                return n
        return None

    def nodes_on_floor(self, fl: int) -> List[Node]:
        return [n for n in self.nodes if n.floor == fl]

    def elevator_group(self, kind: str) -> List[Node]:
        if kind in ("", "none"):
            return []
        return [n for n in self.nodes if n.elevator == kind]

    def elevator_segment(self, node: "Node") -> List[Node]:
        if not node or node.elevator in ("", "none"):
            return [node] if node else []
        for seg in self.elevator_segments(node.elevator):
            if any(n.id == node.id for n in seg):
                return seg
        return [node]

    def elevator_segments(self, kind: str) -> List[List[Node]]:
        ordered = sorted(self.elevator_group(kind), key=lambda z: z.floor)
        segs: List[List[Node]] = []
        cur: List[Node] = []
        for n in ordered:
            cur.append(n)
            if getattr(n, "roof", False):
                segs.append(cur)
                cur = []
        if cur:
            segs.append(cur)
        return segs

    def segment_touching_floor(self, kind: str, floor: int, exclude_id: Optional[str] = None) -> List[Node]:
        """Same-color cars that a new car on `floor` would join. Roof blocks past that floor."""
        if kind in ("", "none"):
            return []
        for seg in self.elevator_segments(kind):
            seg = [n for n in seg if n.id != exclude_id]
            if not seg:
                continue
            lo, hi = seg[0].floor, seg[-1].floor
            capped = getattr(seg[-1], "roof", False)
            if capped:
                if lo <= floor <= hi:
                    return seg
            elif floor >= lo:
                return seg
        return []

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "uid": self.uid,
            "nodes": [n.to_dict() for n in self.nodes],
            "stickers": [s.to_dict() for s in self.stickers],
            "path_routes": getattr(self, "path_routes", blank_path_routes()),
            "ui": dict(getattr(self, "ui", {}) or {}),
        }

    def load_dict(self, d: dict, assets: Optional["AssetStore"] = None):
        self.name = d.get("name", "Placeholder")
        self.uid = int(d.get("uid", 100))
        self.nodes = [Node.from_dict(x) for x in d.get("nodes", [])]
        raw_st = [Sticker.from_dict(x) for x in d.get("stickers", [])]
        if assets is not None:
            self.stickers = [s for s in raw_st if assets.has_sticker(s.name)]
        else:
            self.stickers = raw_st
        self.path_routes = blank_path_routes()
        raw_pr = d.get("path_routes") or {}
        if isinstance(raw_pr, dict):
            for color in PATH_DOT_COLORS:
                short = color.replace("_Path", "")
                src = (raw_pr.get(color) or raw_pr.get(color.lower())
                       or raw_pr.get(short) or raw_pr.get(short.lower()) or {})
                ids = list(src.get("ids") or [])
                direc = 1 if int(src.get("dir", 1) or 1) >= 0 else -1
                self.path_routes[color] = {"ids": ids, "dir": direc}
        live = {s.id for s in self.stickers}
        for color, bucket in self.path_routes.items():
            bucket["ids"] = [i for i in bucket.get("ids") or [] if i in live]
        for st in self.stickers:
            if path_dot_color(st.name):
                register_path_dot(self, st)
        resolve_imported_layout(self)
        ensure_reciprocal_ports(self)
        prune_edge_ports(self)
        self.ui = dict(d.get("ui") or {}) if isinstance(d.get("ui"), dict) else {}

    def seed_default(self):
        self.nodes.clear()
        self.stickers.clear()
        self.path_routes = blank_path_routes()
        self.uid = 1
        self.name = "Placeholder"


def retarget_node_title(state: "MapState", old: str, new: str) -> None:
    o = (old or "").strip().lower()
    if not o or not (new or "").strip():
        return
    for n in state.nodes:
        for pdata in n.ports.values():
            tgt = (pdata.get("target") or "").strip()
            if tgt.lower() == o:
                pdata["target"] = new


# ---------------------------------------------------------------------------
# Asset store + thumbnails
# ---------------------------------------------------------------------------

class AssetStore:
    def __init__(self):
        self.images: Dict[str, Image.Image] = {}
        self.thumbs: Dict[str, Image.Image] = {}
        self.sticker_names: List[str] = []
        self.catalog_entries: List[tuple] = []
        self.starred_folders: set = set()
        self.thumb_folder = THUMBS_DIR
        self.grid_index: Dict[str, str] = {}
        self.sticker_index: Dict[str, str] = {}
        self.fallback_index: Dict[str, str] = {}

    def load_json(self, path: str = "") -> str:
        extra: Dict[str, str] = {}
        if path and os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            stickers = meta.get("stickers") if isinstance(meta, dict) else None
            if isinstance(stickers, dict):
                extra = {str(k): str(v) for k, v in stickers.items()}
            thumbs = meta.get("catalog_thumbnails") if isinstance(meta, dict) else None
            if thumbs:
                self.thumb_folder = thumbs
        return self.reload_images(extra)

    def reload_images(self, extra_stickers: Optional[Dict[str, str]] = None) -> str:
        self.images.clear()
        ensure_path_route_assets()
        self.grid_index = scan_png_tree(GRID_ASSETS_DIR, skip_fallback=True)
        self.sticker_index = scan_png_tree(STICKER_ASSETS_DIR, skip_fallback=True)
        self.fallback_index = {}
        self.fallback_index.update(scan_png_tree(FALLBACK_ASSETS_DIR, skip_fallback=False))
        self.fallback_index.update(scan_png_tree(FALLBACK_GRID_DIR, skip_fallback=False))
        self.fallback_index.update(scan_png_tree(FALLBACK_STICKER_DIR, skip_fallback=False))
        if extra_stickers:
            for k, p in extra_stickers.items():
                self.sticker_index[k] = p
                self.sticker_index[k.lower()] = p
        entries, names = walk_sticker_catalog(STICKER_ASSETS_DIR, getattr(self, "starred_folders", None))
        if extra_stickers:
            extra_names = []
            for k, p in extra_stickers.items():
                if not p or not os.path.isfile(p):
                    continue
                nm = os.path.splitext(os.path.basename(p))[0]
                if nm not in names:
                    extra_names.append(nm)
            if extra_names:
                entries.append(("cat", "Imported"))
                entries.extend(("item", n) for n in extra_names)
                names.extend(extra_names)
        self.catalog_entries = entries
        self.sticker_names = names
        os.makedirs(self.thumb_folder, exist_ok=True)
        self.sync_thumbnails()
        return "ok"

    def _open(self, name: str, p: str) -> Optional[Image.Image]:
        if not p or not os.path.isfile(p):
            return None
        img = Image.open(p).convert("RGBA")
        if img.width * img.height <= 65536:
            img = defringe_rgba(img)
        self.images[name] = img
        self.images[name.lower()] = img
        return img

    def _resolve(self, *names: str) -> str:
        p = lookup_png(self.grid_index, *names) or lookup_png(self.sticker_index, *names)
        if p:
            return p
        return lookup_png(getattr(self, "fallback_index", {}), *names)

    def has_sticker(self, name: str) -> bool:
        if not name:
            return False
        return bool(lookup_png(self.sticker_index, name)
                    or lookup_png(getattr(self, "fallback_index", {}), name))

    def get(self, name: str) -> Optional[Image.Image]:
        if not name:
            return None
        img = self.images.get(name) or self.images.get(name.lower())
        if img is not None:
            return img
        p = lookup_png(self.sticker_index, name)
        if p:
            return self._open(name, p)
        return self._open(name, self._resolve(name))

    def get_material(self, kind: str, stars: str = "") -> Optional[Image.Image]:
        if not kind or kind == "Empty":
            return None
        names = material_file_names(kind, stars)
        fb = getattr(self, "fallback_index", {})
        for key in names:
            img = self.images.get(key) or self.images.get(key.lower())
            if img is not None:
                return img
            p = lookup_png(self.grid_index, key) or lookup_png(fb, key)
            if p:
                return self._open(key, p)
        return None

    def get_elevator(self, kind: str) -> Optional[Image.Image]:
        names = elevator_file_names(kind)
        for n in names:
            img = self.images.get(n) or self.images.get(n.lower())
            if img is not None:
                return img
        return self._open(names[0], self._resolve(*names))

    def sync_thumbnails(self, force: bool = False):
        os.makedirs(self.thumb_folder, exist_ok=True)
        wanted = set(self.sticker_names)
        for name in self.sticker_names:
            thumb_path = os.path.join(self.thumb_folder, f"{name}.webp")
            thumb_png = os.path.join(self.thumb_folder, f"{name}.png")
            src = self.get(name)
            if src is None:
                continue
            existing = thumb_path if os.path.isfile(thumb_path) else thumb_png
            if not force and os.path.isfile(existing):
                try:
                    self.thumbs[name] = Image.open(existing).convert("RGBA")
                    continue
                except Exception:
                    pass
            thumb = make_thumb(src, 64)
            thumb.save(thumb_path, format="WEBP", quality=80)
            self.thumbs[name] = thumb
        if os.path.isdir(self.thumb_folder):
            for fn in os.listdir(self.thumb_folder):
                if not fn.lower().endswith((".png", ".webp")):
                    continue
                key = os.path.splitext(fn)[0]
                if key not in wanted:
                    try:
                        os.remove(os.path.join(self.thumb_folder, fn))
                    except OSError:
                        pass
                    self.thumbs.pop(key, None)


def defringe_rgba(img: Image.Image) -> Image.Image:
    """Drop hairline fringe. Do not recolor pixels (that causes color bloom)."""
    img = img.convert("RGBA")
    extrema = img.getextrema()
    if not extrema or extrema[3][0] == 255:
        return img
    cut = 28
    img.putdata([(0, 0, 0, 0) if p[3] < cut else p for p in img.getdata()])
    return img


def paste_rgba(base: Image.Image, sprite: Image.Image, xy: Tuple[int, int]) -> None:
    """Composite sprite with real alpha (no black-mask fringe)."""
    if sprite is None:
        return
    x, y = int(xy[0]), int(xy[1])
    sw, sh = sprite.size
    bw, bh = base.size
    sx0 = 0 if x >= 0 else -x
    sy0 = 0 if y >= 0 else -y
    dx0 = max(x, 0)
    dy0 = max(y, 0)
    dx1 = min(x + sw, bw)
    dy1 = min(y + sh, bh)
    if dx1 <= dx0 or dy1 <= dy0:
        return
    crop = sprite.crop((sx0, sy0, sx0 + (dx1 - dx0), sy0 + (dy1 - dy0)))
    dest = base.crop((dx0, dy0, dx1, dy1))
    base.paste(Image.alpha_composite(dest, crop), (dx0, dy0))


def make_thumb(img: Image.Image, size: int = 64) -> Image.Image:
    canvas = Image.new("RGBA", (size, size), (30, 30, 30, 255))
    src = img.copy()
    src.thumbnail((size - 6, size - 6), Image.Resampling.LANCZOS)
    ox = (size - src.width) // 2
    oy = (size - src.height) // 2
    paste_rgba(canvas, src, (ox, oy))
    return canvas


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def floor_top_y(floor_idx: int, floor_count: int) -> int:
    """World Y of the top of a floor panel. B1 is at the bottom."""
    # floors stacked: highest floor at y=0
    # floor_count panels: indices 0..floor_count-1 where 0=B1
    return (floor_count - 1 - floor_idx) * FLOOR_H


def node_y_on_floor(floor_idx: int, floor_count: int, min_floor: int = 0) -> int:
    top = floor_top_y(int(floor_idx) - int(min_floor), floor_count)
    return top + (FLOOR_H - NODE_H) // 2


def blue_elevator_x() -> int:
    """Preferred spawn: map center, then half a node left. Not a lock column."""
    return snap((MAP_W - NODE_W) // 2 - NODE_W // 2)


def port_position(node: Node, port: str, floor_count: int, min_floor: int = 0) -> Tuple[int, int]:
    """Top-left of node_connect for a port."""
    ny = node_y_on_floor(node.floor, floor_count, min_floor)
    nx = node.x
    cw, ch = CONNECT_W, CONNECT_H
    top = port.startswith("top")
    if top:
        cy = ny - ch + CONNECT_OVERLAP
    else:
        cy = ny + NODE_H - CONNECT_OVERLAP
    if port.endswith("mid"):
        cx = snap(nx + (NODE_W - cw) // 2)
    elif port.endswith("left"):
        cx = nx + GRID - cw // 2
    else:
        cx = nx + snap(NODE_W) - GRID - cw // 2
    return cx, cy


def port_exit(node: Node, port: str, floor_count: int, min_floor: int = 0) -> Tuple[float, float]:
    """Noodle origin: outer tip of node_connect, not the node box."""
    x, y = port_position(node, port, floor_count, min_floor)
    cx = x + CONNECT_W / 2
    if port.startswith("top"):
        return cx, y + 1
    return cx, y + CONNECT_H - 1


def node_center(node: Node, floor_count: int, min_floor: int = 0) -> Tuple[float, float]:
    return node.x + NODE_W / 2, node_y_on_floor(node.floor, floor_count, min_floor) + NODE_H / 2


def bezier_points(p0, p1, p2, p3, steps=32) -> List[Tuple[int, int]]:
    pts = []
    for i in range(steps + 1):
        t = i / steps
        u = 1 - t
        x = u**3 * p0[0] + 3 * u**2 * t * p1[0] + 3 * u * t**2 * p2[0] + t**3 * p3[0]
        y = u**3 * p0[1] + 3 * u**2 * t * p1[1] + 3 * u * t**2 * p2[1] + t**3 * p3[1]
        pts.append((int(x), int(y)))
    return pts


def connection_curve(a: Tuple[float, float], b: Tuple[float, float],
                     src_port: str = "und_mid", dest_port: str = "top_mid"):
    """Cubic always leaves away from the port (up from top, down from und)."""
    dist = math.hypot(b[0] - a[0], b[1] - a[1])
    reach = max(20, min(52, dist * 0.16 + 16))
    sdir = -1 if src_port.startswith("top") else 1
    ddir = -1 if dest_port.startswith("top") else 1
    dx = b[0] - a[0]
    c1 = (a[0] + dx * 0.12, a[1] + sdir * reach)
    c2 = (b[0] - dx * 0.12, b[1] + ddir * reach)
    return bezier_points(a, c1, c2, b, 24)


def aa_polyline(canvas: Image.Image, pts, color: Tuple[int, int, int], width: float = 3.5):
    """Draw an antialiased polyline via 2x supersample."""
    if not pts or len(pts) < 2 or canvas is None:
        return
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    pad = int(math.ceil(width)) + 3
    minx, miny = int(math.floor(min(xs))) - pad, int(math.floor(min(ys))) - pad
    maxx, maxy = int(math.ceil(max(xs))) + pad, int(math.ceil(max(ys))) + pad
    w, h = max(2, maxx - minx), max(2, maxy - miny)
    scale = 2
    ov = Image.new("RGBA", (w * scale, h * scale), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    spts = [((p[0] - minx) * scale, (p[1] - miny) * scale) for p in pts]
    lw = max(1, int(round(width * scale)))
    d.line(spts, fill=color + (255,), width=lw, joint="curve")
    ov = ov.resize((w, h), Image.BILINEAR)
    if minx < canvas.width and miny < canvas.height and minx + w > 0 and miny + h > 0:
        paste_rgba(canvas, ov, (minx, miny))


def fold_search(s: str) -> str:
    return (s or "").lower().replace(" ", "_")


def resolved_port_targets(node: Node, state: MapState) -> List[Tuple[str, Node]]:
    found = []
    for pk, p in node.ports.items():
        t = (p.get("target") or "").strip()
        if not t or t == EDGE_TARGET:
            continue
        other = state.find_by_title(t)
        if other is not None and other.id != node.id:
            found.append((pk, other))
    return found


def node_has_drawn_line(node: Node, state: MapState) -> bool:
    if node.elevator and node.elevator != "none":
        if len(state.elevator_segment(node)) >= 2:
            return True
    if any((p.get("target") or "").strip() == EDGE_TARGET for p in node.ports.values()):
        return True
    return bool(resolved_port_targets(node, state))


def node_is_invalid(node: Node, state: MapState) -> bool:
    """Red border if no drawn lines, or illegal port geometry / duplicates."""
    targets = resolved_port_targets(node, state)
    names = [o.title.strip().lower() for _pk, o in targets]
    if any(names.count(t) > 2 for t in set(names)):
        return True
    for pk, other in targets:
        if not dest_floor_ok(node, pk, other):
            return True
    if not node_has_drawn_line(node, state):
        return True
    return False


def floor_move_blocked(node: Node, new_floor: int, state: MapState) -> Optional[str]:
    """Refuse a floor change that would make a port same-row or up/down mismatch."""
    if new_floor == node.floor:
        return None
    old = node.floor
    node.floor = new_floor
    try:
        if node_is_invalid(node, state) and resolved_port_targets(node, state):
            for pk, other in resolved_port_targets(node, state):
                if other.floor == new_floor:
                    return f"REFUSED: {node.title} would share floor {floor_label(new_floor)} with {other.title}"
                if pk.startswith("top") and other.floor < new_floor:
                    return f"REFUSED: top port of {node.title} cannot connect downward to {other.title}"
                if pk.startswith("und") and other.floor > new_floor:
                    return f"REFUSED: und port of {node.title} cannot connect upward to {other.title}"
            return f"REFUSED: moving {node.title} to {floor_label(new_floor)} breaks a port"
        title = node.title.strip().lower()
        for o in state.nodes:
            if o.id == node.id:
                continue
            for pk, pdata in o.ports.items():
                if (pdata.get("target") or "").strip().lower() != title:
                    continue
                if not dest_floor_ok(o, pk, node):
                    return f"REFUSED: {o.title}.{pk} would mismatch after moving {node.title}"
    finally:
        node.floor = old
    return None


def opposite_port_side(port: str) -> str:
    return "und" if port.startswith("top") else "top"


def port_side_ok(src_port: str, dest_port: str) -> bool:
    return dest_port.startswith(opposite_port_side(src_port))


def dest_floor_ok(src: Node, src_port: str, dest: Node) -> bool:
    if dest.id == src.id:
        return False
    if src_port.startswith("top"):
        return dest.floor > src.floor
    return dest.floor < src.floor


def clear_port_link(node: Node, port: str, state: MapState):
    tgt = (node.ports[port].get("target") or "").strip()
    node.ports[port]["target"] = ""
    if not tgt or tgt == EDGE_TARGET:
        return
    other = state.find_by_title(tgt)
    if other is None:
        return
    title = node.title.strip().lower()
    hits = [pk for pk, pdata in other.ports.items()
            if (pdata.get("target") or "").strip().lower() == title]
    dest = pick_matching_port(port, hits)
    if dest is None and hits:
        dest = hits[0]
    if dest:
        other.ports[dest]["target"] = ""


def make_port_link(src: Node, src_port: str, dest: Node, dest_port: str,
                   state: Optional["MapState"] = None):
    """Link ports. Up to two links between the same node pair."""
    st = src.title.strip().lower()
    dt = dest.title.strip().lower()
    src.ports[src_port]["target"] = dest.title
    dest.ports[dest_port]["target"] = src.title
    col = src.ports[src_port].get("color", "cyan")
    dest.ports[dest_port]["color"] = col
    src.ports[src_port]["color"] = col


def port_tail(port: str) -> str:
    if port.endswith("left"):
        return "left"
    if port.endswith("right"):
        return "right"
    return "mid"


def pick_matching_port(src_port: str, hits: List[str]) -> Optional[str]:
    if not hits:
        return None
    tail = port_tail(src_port)
    for pk in hits:
        if pk.endswith(tail) and port_side_ok(src_port, pk):
            return pk
    for pk in hits:
        if port_side_ok(src_port, pk):
            return pk
    return hits[0]


def paired_dest_port(node: Node, port: str, other: Node) -> Optional[str]:
    title = node.title.strip().lower()
    hits = [pk for pk, p in other.ports.items()
            if (p.get("target") or "").strip().lower() == title]
    return pick_matching_port(port, hits)


def sync_link_color(node: Node, port: str, color: str, state: MapState):
    node.ports[port]["color"] = color
    tgt = (node.ports[port].get("target") or "").strip()
    if not tgt:
        return
    other = state.find_by_title(tgt)
    if other is None:
        return
    dest = paired_dest_port(node, port, other)
    if dest:
        other.ports[dest]["color"] = color


def ensure_reciprocal_ports(state: MapState):
    """If A points at B but B has no port back, fill the matching side."""
    for n in list(state.nodes):
        for pk, pdata in n.ports.items():
            tgt = (pdata.get("target") or "").strip()
            if not tgt:
                continue
            other = state.find_by_title(tgt)
            if other is None:
                continue
            title = n.title.strip().lower()
            if any((p.get("target") or "").strip().lower() == title for p in other.ports.values()):
                continue
            if other.floor < n.floor:
                side = "top"
            elif other.floor > n.floor:
                side = "und"
            else:
                side = "und" if pk.startswith("top") else "top"
            dest_pk = f"{side}_mid"
            if (other.ports[dest_pk].get("target") or "").strip():
                for cand in PORT_KEYS:
                    if cand.startswith(side) and not (other.ports[cand].get("target") or "").strip():
                        dest_pk = cand
                        break
            other.ports[dest_pk]["target"] = n.title
            other.ports[dest_pk]["color"] = pdata.get("color", "cyan")


def prune_edge_ports(state: MapState):
    if not state.nodes:
        return
    lo, hi = state.min_floor(), state.max_floor()
    for n in state.nodes:
        for pk, pdata in n.ports.items():
            if (pdata.get("target") or "").strip() != EDGE_TARGET:
                continue
            if pk.startswith("top") and n.floor != hi:
                pdata["target"] = ""
            elif pk.startswith("und") and n.floor != lo:
                pdata["target"] = ""


def sticker_world(st: Sticker) -> Tuple[int, int]:
    return int(st.tile_x), int(st.tile_y)


def sticker_size(name: str, assets: "AssetStore", big: bool = False) -> Tuple[int, int]:
    img = assets.get(name)
    if img is None:
        w, h = GRID, GRID
    else:
        w, h = img.width, img.height
    if big:
        return int(w * 1.5), int(h * 1.5)
    return w, h


def clamp_sticker_xy(px: int, py: int, state: "MapState", assets: "AssetStore",
                     name: str, big: bool = False) -> Tuple[int, int]:
    w, h = sticker_size(name, assets, big)
    max_x = max(0, MAP_W - w)
    max_y = max(0, state.floor_count() * FLOOR_H - h)
    return clamp(int(px), 0, max_x), clamp(int(py), 0, max_y)


def path_dot_color(name: str) -> str:
    n = (name or "").strip()
    low = n.lower()
    for c in PATH_DOT_COLORS:
        if low == c.lower() or low + "_path" == c.lower() or low == c.lower().replace("_path", ""):
            return c
    return ""


def blank_path_routes() -> Dict[str, dict]:
    return {c: {"ids": [], "dir": 1} for c in PATH_DOT_COLORS}


def ensure_path_route_assets():
    dest_dir = os.path.join(STICKER_ASSETS_DIR, PATH_ROUTE_DIR)
    os.makedirs(dest_dir, exist_ok=True)
    copied = False
    for color in PATH_DOT_COLORS:
        if any(os.path.isfile(os.path.join(dest_dir, f"{color}{ext}")) for ext in (".webp", ".png")):
            continue
        src = ""
        for root in (FALLBACK_STICKER_DIR, FALLBACK_ASSETS_DIR, FALLBACK_GRID_DIR):
            if not root or not os.path.isdir(root):
                continue
            for sub in (os.path.join(root, PATH_ROUTE_DIR), root):
                for fn in (f"{color}.webp", f"{color}.png", f"{color.lower()}.webp", f"{color.lower()}.png"):
                    p = os.path.join(sub, fn)
                    if os.path.isfile(p):
                        src = p
                        break
                if src:
                    break
            if src:
                break
        if src:
            dest = os.path.join(dest_dir, f"{color}{os.path.splitext(src)[1].lower()}")
            try:
                shutil.copy2(src, dest)
                copied = True
            except Exception:
                pass
    return copied


def register_path_dot(state: "MapState", st: Sticker, selected_id: Optional[str] = None):
    color = path_dot_color(st.name)
    if not color:
        return
    if not getattr(state, "path_routes", None):
        state.path_routes = blank_path_routes()
    bucket = state.path_routes.setdefault(color, {"ids": [], "dir": 1})
    ids = bucket.setdefault("ids", [])
    if st.id in ids:
        return
    if selected_id and ids and selected_id == ids[0]:
        ids.insert(0, st.id)
    else:
        ids.append(st.id)


def insert_path_dot_between(state: "MapState", assets: "AssetStore",
                            a: Sticker, b: Sticker) -> Optional[Sticker]:
    color = path_dot_color(a.name)
    if not color or path_dot_color(b.name) != color or a.id == b.id:
        return None
    bucket = (getattr(state, "path_routes", None) or {}).get(color) or {}
    ids = list(bucket.get("ids") or [])
    if a.id not in ids or b.id not in ids:
        return None
    ia, ib = ids.index(a.id), ids.index(b.id)
    if abs(ia - ib) != 1:
        return None
    ax, ay = sticker_world(a)
    bx, by = sticker_world(b)
    tx, ty = clamp_sticker_xy(int(round((ax + bx) / 2)), int(round((ay + by) / 2)),
                              state, assets, a.name, False)
    st = Sticker(id=state.next_id("s"), name=a.name, tile_x=tx, tile_y=ty, big=False)
    state.stickers.append(st)
    ids.insert(min(ia, ib) + 1, st.id)
    bucket["ids"] = ids
    return st


def unregister_path_dot(state: "MapState", sid: str):
    routes = getattr(state, "path_routes", None) or {}
    for bucket in routes.values():
        ids = list(bucket.get("ids") or [])
        if sid in ids:
            ids.remove(sid)
            bucket["ids"] = ids


def drop_stickers(state: "MapState", drop_ids, selected_sticker: Optional[str] = None):
    drop = set(drop_ids or [])
    for sid in drop:
        unregister_path_dot(state, sid)
    state.stickers = [s for s in state.stickers if s.id not in drop]
    if selected_sticker in drop:
        return None
    return selected_sticker


def pop_last_path_dot(state: "MapState", color: str, selected_sticker: Optional[str] = None):
    bucket = (getattr(state, "path_routes", None) or {}).get(color) or {}
    ids = list(bucket.get("ids") or [])
    if not ids:
        return selected_sticker, False
    last = ids[-1]
    return drop_stickers(state, [last], selected_sticker), True


def clear_path_color(state: "MapState", color: str, selected_sticker: Optional[str] = None):
    bucket = (getattr(state, "path_routes", None) or {}).get(color) or {}
    ids = list(bucket.get("ids") or [])
    if not ids:
        return selected_sticker, False
    sel = drop_stickers(state, ids, selected_sticker)
    bucket["ids"] = []
    return sel, True


def path_dot_center(st: Sticker, assets: "AssetStore") -> Tuple[float, float]:
    x, y = sticker_world(st)
    w, h = sticker_size(st.name, assets, getattr(st, "big", False))
    return x + w / 2.0, y + h / 2.0


def _vsub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def _vadd(a, b):
    return (a[0] + b[0], a[1] + b[1])


def _vmul(a, s):
    return (a[0] * s, a[1] * s)


def _vlen(a):
    return math.hypot(a[0], a[1]) or 1.0


def rounded_path(points: List[Tuple[float, float]], radius: float = 16.0) -> List[Tuple[int, int]]:
    """Catmull-Rom through every waypoint, blended toward the chord so corners stay mild."""
    if len(points) < 2:
        return [(int(p[0]), int(p[1])) for p in points]
    if len(points) == 2:
        a, b = points[0], points[1]
        return [(int(a[0]), int(a[1])), (int(b[0]), int(b[1]))]
    pts = [points[0]] + list(points) + [points[-1]]
    out: List[Tuple[int, int]] = [(int(points[0][0]), int(points[0][1]))]
    bend = 0.45
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[i + 1], pts[i + 2]
        steps = 8
        for k in range(1, steps + 1):
            t = k / steps
            t2, t3 = t * t, t * t * t
            sx = 0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t
                        + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2
                        + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3)
            sy = 0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t
                        + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2
                        + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
            lx = p1[0] + (p2[0] - p1[0]) * t
            ly = p1[1] + (p2[1] - p1[1]) * t
            x = lx * (1.0 - bend) + sx * bend
            y = ly * (1.0 - bend) + sy * bend
            out.append((int(x), int(y)))
    return out


def draw_path_arrows(draw: ImageDraw.ImageDraw, pts: List[Tuple[int, int]],
                     color: Tuple[int, int, int], forward: bool = True):
    if len(pts) < 2:
        return
    seq = pts if forward else list(reversed(pts))
    segs = []
    for i in range(1, len(seq)):
        x0, y0 = seq[i - 1]
        x1, y1 = seq[i]
        d = math.hypot(x1 - x0, y1 - y0)
        segs.append((x0, y0, x1, y1, d))
    spacing = 78.0
    acc = spacing * 0.6
    size = 12.0
    for x0, y0, x1, y1, d in segs:
        if d < 1:
            continue
        while acc <= d:
            u = acc / d
            px = x0 + (x1 - x0) * u
            py = y0 + (y1 - y0) * u
            ang = math.atan2(y1 - y0, x1 - x0)
            tip = (px + math.cos(ang) * size, py + math.sin(ang) * size)
            left = (px + math.cos(ang + 2.5) * size * 0.72,
                    py + math.sin(ang + 2.5) * size * 0.72)
            right = (px + math.cos(ang - 2.5) * size * 0.72,
                     py + math.sin(ang - 2.5) * size * 0.72)
            draw.polygon([tip, left, right], fill=color + (255,))
            acc += spacing
        acc -= d
        if acc < 0:
            acc = 0


def adjust_stickers_after_floor_change(state: "MapState", assets: "AssetStore", old_fc: int,
                                      skip_ids=None):
    """Shift stickers when the tower height changes; drop any that sit above the new top."""
    new_fc = state.floor_count()
    if new_fc == old_fc:
        return
    skip = set(skip_ids or [])
    dy = (old_fc - new_fc) * FLOOR_H
    keep = []
    for st in state.stickers:
        if st.id not in skip:
            st.tile_y -= dy
        w, h = sticker_size(st.name, assets, getattr(st, "big", False))
        if st.tile_y < 0:
            continue
        st.tile_x, st.tile_y = clamp_sticker_xy(st.tile_x, st.tile_y, state, assets, st.name, getattr(st, "big", False))
        if st.tile_y + h <= new_fc * FLOOR_H and st.tile_x + w <= MAP_W:
            keep.append(st)
    state.stickers = keep


def sticker_hits_node(st: Sticker, node: Node, assets: "AssetStore", fc: int, pad: int = 24,
                     min_floor: int = 0) -> bool:
    img = assets.get(st.name)
    if img is None:
        return False
    sx, sy = sticker_world(st)
    w, h = sticker_size(st.name, assets, getattr(st, "big", False))
    ny = node_y_on_floor(node.floor, fc, min_floor)
    return (sx + w >= node.x - pad and sx <= node.x + NODE_W + pad and
            sy + h >= ny - pad and sy <= ny + NODE_H + pad)


def sticker_locked_on_node(st: Sticker, state: MapState, assets: "AssetStore") -> bool:
    fc = state.floor_count()
    return any(sticker_hits_node(st, n, assets, fc, min_floor=state.min_floor()) for n in state.nodes)


def pil_to_surf(img: Image.Image):
    import pygame
    to_surf = getattr(pygame.image, "frombytes", pygame.image.fromstring)
    return to_surf(img.tobytes(), img.size, img.mode)


# ---------------------------------------------------------------------------
# PIL renderer (used both for editor blit source and final export)
# ---------------------------------------------------------------------------


def _floor_bg_slice(fl, t_floor, j_floor, bg_norm, bg_t0, bg_t, bg_j0, bg_j):
    """Return (image, src_y) for one floor. Flip never applies to goku art."""
    def band_src(img, index_from_top, bands=10):
        if img is None:
            return None, 0
        step = max(1, img.height // bands)
        idx = max(0, min(bands - 1, int(index_from_top)))
        return img, idx * step

    if t_floor is not None:
        if t_floor <= fl <= t_floor + 9:
            # T at bottom of starting strip, T+9 at top
            return band_src(bg_t0 or bg_t or bg_norm, (t_floor + 9) - fl)
        if fl > t_floor + 9:
            img = bg_t or bg_t0 or bg_norm
            if img is None:
                return None, 0
            step = max(1, FLOOR_H)
            return img, ((fl - (t_floor + 10)) * step) % max(1, img.height)
    if j_floor is not None:
        if j_floor - 9 <= fl <= j_floor:
            # J at top of starting strip, J-9 at bottom
            return band_src(bg_j0 or bg_j or bg_norm, j_floor - fl)
        if fl < j_floor - 9:
            img = bg_j or bg_j0 or bg_norm
            if img is None:
                return None, 0
            return img, ((j_floor - 10 - fl) * FLOOR_H) % max(1, img.height)
    if bg_norm is None:
        return None, 0
    return bg_norm, (fl * FLOOR_H) % max(1, bg_norm.height)


def find_zone_node(state: "MapState", kind: str):
    key = "tengoku" if kind == "tengoku" else "jigoku"
    for n in state.nodes:
        if getattr(n, key, False):
            return n
    return None


def apply_zone_flag(state: "MapState", node: "Node", kind: str, on: bool) -> str:
    """Set tengoku/jigoku on one node. Returns empty or REFUSED message."""
    if node is None:
        return "REFUSED: no node selected"
    other = "jigoku" if kind == "tengoku" else "tengoku"
    if on and getattr(node, other, False):
        setattr(node, other, False)
    t = find_zone_node(state, "tengoku")
    j = find_zone_node(state, "jigoku")
    if on and kind == "tengoku":
        if j is not None and node.floor <= j.floor:
            return "REFUSED: Tengoku cannot be on or below Jigoku"
        for n in state.nodes:
            if n.id != node.id:
                n.tengoku = False
        node.tengoku = True
        node.jigoku = False
        return ""
    if on and kind == "jigoku":
        if t is not None and node.floor >= t.floor:
            return "REFUSED: Jigoku cannot be on or above Tengoku"
        for n in state.nodes:
            if n.id != node.id:
                n.jigoku = False
        node.jigoku = True
        node.tengoku = False
        return ""
    setattr(node, kind, False)
    return ""


def connect_goku_floors(state: "MapState") -> str:
    t = find_zone_node(state, "tengoku")
    j = find_zone_node(state, "jigoku")
    if t is None and j is None:
        return "REFUSED: no Tengoku or Jigoku floor"
    linked = 0

    def chain(pred):
        nonlocal linked
        by = {}
        for n in state.nodes:
            by.setdefault(n.floor, []).append(n)
        ordered = []
        for fl in sorted(by):
            if not pred(fl):
                continue
            if len(by[fl]) != 1:
                continue
            ordered.append(by[fl][0])
        for a, b in zip(ordered, ordered[1:]):
            clear_port_link(a, "top_mid", state)
            clear_port_link(b, "und_mid", state)
            make_port_link(a, "top_mid", b, "und_mid")
            linked += 1

    if t is not None:
        chain(lambda fl, T=t.floor: fl >= T)
    if j is not None:
        chain(lambda fl, J=j.floor: fl <= J)
    if linked == 0:
        return "No single-node floors to connect."
    return f"Connected {linked} goku link(s)."



BADGE_S = 36

def _draw_sticker_badges(canvas, assets, st, px, py, sw, sh):
    lv = badge_text(getattr(st, "level", ""))
    am = badge_text(getattr(st, "amount", ""))
    if not lv and not am:
        return
    # Level centered on top edge, amount on bottom edge.
    lx = px + sw / 2 - BADGE_S / 2
    ly = py - BADGE_S / 2 - 8
    ax = px + sw / 2 - BADGE_S / 2
    ay = py + sh - BADGE_S / 2 + 8
    if lv and am:
        while ay < ly + BADGE_S:
            ly -= 1
            ay += 1
            if ay - (ly + BADGE_S) >= 1:
                break
    font = load_font(16, True)
    draw = ImageDraw.Draw(canvas)

    def stamp(icon_name, fallback_star, bx, by, text):
        icon = assets.get(icon_name) if icon_name else None
        if icon is None and fallback_star:
            icon = assets.get("Star")
        if icon is not None:
            if icon.size != (BADGE_S, BADGE_S):
                icon = icon.resize((BADGE_S, BADGE_S), Image.Resampling.LANCZOS)
            paste_rgba(canvas, icon, (int(bx), int(by)))
        else:
            draw.ellipse([bx, by, bx + BADGE_S, by + BADGE_S], fill=(40, 40, 48, 220))
        bb = draw.textbbox((0, 0), text, font=font)
        tw, th = bb[2] - bb[0], bb[3] - bb[1]
        draw.text((bx + (BADGE_S - tw) / 2 - bb[0], by + (BADGE_S - th) / 2 - bb[1]),
                  text, font=font, fill=(0, 0, 0, 255))

    if lv:
        stamp("Star", False, lx, ly, lv)
    if am:
        stamp("Amount", True, ax, ay, am)


class MapRenderer:
    def __init__(self, assets: AssetStore):
        self.assets = assets

    def render(self, state: MapState, crop: bool = False,
               selected_node: Optional[str] = None,
               selected_sticker: Optional[str] = None,
               view_box: Optional[Tuple[int, int, int, int]] = None,
               hide_stickers: bool = False,
               hide_paths: bool = False,
               live: bool = False,
               red_blink: bool = True,
               flip_bg: bool = False) -> Image.Image:
        fc = state.floor_count()
        mf = state.min_floor()
        W, H = MAP_W, fc * FLOOR_H
        if view_box is None:
            ox, oy, vx1, vy1 = 0, 0, W, H
        else:
            ox = max(0, int(view_box[0]))
            oy = max(0, int(view_box[1]))
            vx1 = min(W, int(view_box[2]))
            vy1 = min(H, int(view_box[3]))
        cw, ch = max(1, vx1 - ox), max(1, vy1 - oy)
        canvas = Image.new("RGBA", (cw, ch), (20, 20, 20, 255))

        def vis(x0, y0, x1, y1) -> bool:
            return not (x1 < ox or y1 < oy or x0 > vx1 or y0 > vy1)

        # --- background panels (only visible band of the 10-floor strip) ---
        t_floor = next((n.floor for n in state.nodes if getattr(n, "tengoku", False)), None)
        j_floor = next((n.floor for n in state.nodes if getattr(n, "jigoku", False)), None)
        bg_norm = self.assets.get("floor_bg")
        if bg_norm is not None and flip_bg:
            bg_norm = bg_norm.transpose(Image.ROTATE_180)
        bg_t0 = self.assets.get("starting_tengoku_bg")
        bg_t = self.assets.get("tengoku_floor_bg")
        bg_j0 = self.assets.get("starting_jigoku_bg")
        bg_j = self.assets.get("jigoku_floor_bg")
        for fi in range(fc):
            fl = mf + fi
            top = floor_top_y(fi, fc)
            if top + FLOOR_H < oy or top > vy1:
                continue
            img, src_y = _floor_bg_slice(fl, t_floor, j_floor, bg_norm, bg_t0, bg_t, bg_j0, bg_j)
            if img is None:
                continue
            ih = img.height
            sy = src_y % max(1, ih)
            take = min(FLOOR_H, ih - sy)
            part = img.crop((0, sy, min(MAP_W, img.width), sy + take))
            canvas.paste(part, (0 - ox, top - oy), part)
            if take < FLOOR_H:
                part2 = img.crop((0, 0, min(MAP_W, img.width), FLOOR_H - take))
                canvas.paste(part2, (0 - ox, top - oy + take), part2)

        # floor number boxes
        box = self.assets.get("floor_number_box")
        if box is None:
            box = Image.new("RGBA", FLOOR_BOX, (18, 18, 18, 230))
        bw, bh = box.size
        font = load_font(16, True)
        for fi in range(fc):
            top = floor_top_y(fi, fc)
            bx = int(bw * 0.05)
            by = top + int(bh * 2)
            if not vis(bx, by, bx + bw, by + bh):
                continue
            canvas.paste(box, (bx - ox, by - oy), box)
            label = floor_label(mf + fi)
            td = ImageDraw.Draw(canvas)
            bb = td.textbbox((0, 0), label, font=font)
            tw, th = bb[2] - bb[0], bb[3] - bb[1]
            tx = bx - ox + (bw - tw) / 2
            ty = by - oy + (bh - th) / 2 - 5
            td.text((tx, ty), label, font=font, fill=(255, 255, 255, 255))

        draw = ImageDraw.Draw(canvas)

        # --- connections (behind nodes) ---
        self._draw_elevators(draw, state, fc, ox, oy)
        self._draw_port_cables(canvas, draw, state, fc, ox, oy)

        # --- selection / alert plates (behind nodes) ---
        for n in state.nodes:
            ny = node_y_on_floor(n.floor, fc, mf)
            if not vis(n.x - 6, ny - 6, n.x + NODE_W + 6, ny + NODE_H + 6):
                continue
            box = [n.x - 3 - ox, ny - 3 - oy, n.x + NODE_W + 2 - ox, ny + NODE_H + 2 - oy]
            if node_is_invalid(n, state):
                fill = (150, 22, 22, 200) if (not live or red_blink) else (132, 20, 20, 190)
                try:
                    draw.rounded_rectangle(box, radius=8, fill=fill)
                except Exception:
                    draw.rectangle(box, fill=fill)
            if live and selected_node == n.id:
                plate = self.assets.get("Background_Node_Select")
                if plate is not None:
                    px = int(n.x + NODE_W / 2 - plate.width / 2 - ox)
                    py = int(ny + NODE_H / 2 - plate.height / 2 - oy)
                    paste_rgba(canvas, plate, (px, py))
                else:
                    try:
                        draw.rounded_rectangle(box, radius=8, fill=(210, 210, 214, 220))
                    except Exception:
                        draw.rectangle(box, fill=(210, 210, 214, 220))

        # --- nodes ---
        for n in state.nodes:
            ny = node_y_on_floor(n.floor, fc, mf)
            if not vis(n.x - 40, ny - 40, n.x + NODE_W + 40, ny + NODE_H + 40):
                continue
            self._draw_node(canvas, draw, n, fc, selected=False,
                            ox=ox, oy=oy, min_floor=mf)

        if not hide_paths:
            self._draw_path_routes(canvas, draw, state, ox, oy)

        # --- stickers ---
        if not hide_stickers:
            for st in state.stickers:
                if hide_paths and path_dot_color(st.name):
                    continue
                if not self.assets.has_sticker(st.name):
                    continue
                img = self.assets.get(st.name)
                if img is None:
                    continue
                if getattr(st, "big", False):
                    img = img.resize((int(img.width * 1.5), int(img.height * 1.5)), Image.NEAREST)
                x, y = sticker_world(st)
                if x + img.width < ox or y + img.height < oy or x > vx1 or y > vy1:
                    continue
                paste_rgba(canvas, img, (x - ox, y - oy))
                _draw_sticker_badges(canvas, self.assets, st, x - ox, y - oy, img.width, img.height)
                if selected_sticker == st.id:
                    d2 = ImageDraw.Draw(canvas)
                    d2.rectangle([x - 1 - ox, y - 1 - oy, x + img.width - ox, y + img.height - oy],
                                 outline=(255, 255, 255, 255), width=2)

        # --- port locks above stickers ---
        self._draw_port_locks(canvas, state, fc, mf, ox, oy)
        return canvas

    def _draw_port_locks(self, canvas: Image.Image, state: MapState, fc: int, mf: int,
                         ox: int = 0, oy: int = 0):
        locked = self.assets.get("locked_gate")
        upg = self.assets.get("open_gate_up")
        dng = self.assets.get("open_gate_down")
        for n in state.nodes:
            for pk, pdata in n.ports.items():
                if not (pdata.get("target") or "").strip():
                    continue
                gate = pdata.get("gate", "none")
                if gate in ("open-gate", "none", "", "open"):
                    continue
                gimg = None
                if gate == "closed-gate":
                    gimg = locked
                elif gate == "gate-up":
                    gimg = upg
                elif gate == "gate-down":
                    gimg = dng
                if gimg is None:
                    continue
                px, py = port_position(n, pk, fc, mf)
                cw = CONNECT_W
                gx = px + cw // 2 - gimg.width // 2 - ox
                gh = gimg.height
                ny0 = node_y_on_floor(n.floor, fc, mf) - oy
                top = pk.startswith("top")
                if top:
                    gy = (ny0 - (gh // 2) + 8) if gate == "gate-down" else (ny0 - gh + 8)
                else:
                    bot = ny0 + NODE_H
                    gy = (bot - (gh // 2) - 8) if gate == "gate-up" else (bot - 7)
                paste_rgba(canvas, gimg, (gx, gy))

    def _draw_elevators(self, draw: ImageDraw.ImageDraw, state: MapState, fc: int,
                       ox: int = 0, oy: int = 0):
        # group by color
        kinds = {}
        for n in state.nodes:
            if n.elevator and n.elevator != "none":
                kinds.setdefault(n.elevator, []).append(n)
        for kind, group in kinds.items():
            if len(group) < 1:
                continue
            color = ELEVATOR_HEX.get(kind, (80, 80, 160))
            pairs = []
            if len(group) >= 2:
                ordered = sorted(group, key=lambda z: z.floor)
                for a, b in zip(ordered, ordered[1:]):
                    pairs.append((a, b))
            drawn = set()
            for a, b in pairs:
                if getattr(a, "roof", False):
                    continue
                key = tuple(sorted((a.id, b.id)))
                if key in drawn:
                    continue
                drawn.add(key)
                cxa, _ = port_position(a, "top_mid", fc, state.min_floor())
                shaft_w = CONNECT_W + 2
                x0 = int(cxa - 1 - ox)
                ya = node_center(a, fc, state.min_floor())[1] - oy
                yb = node_center(b, fc, state.min_floor())[1] - oy
                if ya > yb:
                    ya, yb = yb, ya
                draw.rectangle([x0, ya, x0 + shaft_w - 1, yb], fill=color + (255,))

    def _draw_port_cables(self, canvas: Image.Image, draw: ImageDraw.ImageDraw, state: MapState, fc: int,
                         ox: int = 0, oy: int = 0):
        drawn = set()
        used = set()
        for n in state.nodes:
            for pk, pdata in n.ports.items():
                if (n.id, pk) in used:
                    continue
                tgt = (pdata.get("target") or "").strip()
                if not tgt:
                    continue
                if tgt == EDGE_TARGET:
                    a = port_exit(n, pk, fc, state.min_floor())
                    H = fc * FLOOR_H
                    if pk.startswith("top"):
                        b = (a[0], 0.0)
                    else:
                        b = (a[0], float(H))
                    locked = pdata.get("gate") == "closed-gate"
                    col_key = "magenta" if locked else pdata.get("color", "cyan")
                    col = CONN_COLORS.get(col_key, CONN_COLORS["cyan"])
                    aa_polyline(canvas, [(a[0] - ox, a[1] - oy), (b[0] - ox, b[1] - oy)],
                                col, PORT_LINE_W)
                    continue
                other = state.find_by_title(tgt)
                if other is None:
                    continue
                dest_port = self._best_dest_port(n, pk, other, used)
                if not dest_port:
                    continue
                key = tuple(sorted(((n.id, pk), (other.id, dest_port))))
                if key in drawn:
                    continue
                drawn.add(key)
                used.add((n.id, pk))
                used.add((other.id, dest_port))
                a = port_exit(n, pk, fc, state.min_floor())
                b = port_exit(other, dest_port, fc, state.min_floor())
                locked = (pdata.get("gate") == "closed-gate"
                          or other.ports.get(dest_port, {}).get("gate") == "closed-gate")
                col_key = "magenta" if locked else pdata.get("color", "cyan")
                col = CONN_COLORS.get(col_key, CONN_COLORS["cyan"])
                pts = [(p[0] - ox, p[1] - oy) for p in connection_curve(a, b, pk, dest_port)]
                if len(pts) >= 2:
                    aa_polyline(canvas, pts, col, PORT_LINE_W)

    def _draw_path_routes(self, canvas: Image.Image, draw: ImageDraw.ImageDraw,
                          state: MapState, ox: int, oy: int):
        by_id = {s.id: s for s in state.stickers}
        routes = getattr(state, "path_routes", None) or {}
        for color in PATH_DOT_COLORS:
            bucket = routes.get(color) or {}
            ids = [i for i in (bucket.get("ids") or []) if i in by_id]
            if len(ids) < 2:
                continue
            rgb = PATH_DOT_RGB.get(color, (200, 200, 200))
            forward = int(bucket.get("dir", 1) or 1) >= 0
            cents = [path_dot_center(by_id[i], self.assets) for i in ids]
            raw = rounded_path(cents, radius=32.0)
            pts = [(p[0] - ox, p[1] - oy) for p in raw]
            if len(pts) >= 2:
                aa_polyline(canvas, pts, rgb, PATH_LINE_W)
                draw_path_arrows(draw, pts, rgb, forward)

    def _best_dest_port(self, src: Node, src_port: str, dst: Node,
                        used: Optional[set] = None) -> Optional[str]:
        title = src.title.strip().lower()
        used = used or set()
        hits = [pk for pk, pdata in dst.ports.items()
                if (pdata.get("target") or "").strip().lower() == title
                and (dst.id, pk) not in used]
        return pick_matching_port(src_port, hits)

    def _draw_node(self, canvas: Image.Image, draw: ImageDraw.ImageDraw,
                   n: Node, fc: int, selected: bool = False, ox: int = 0, oy: int = 0,
                   min_floor: int = 0):
        ny = node_y_on_floor(n.floor, fc, min_floor) - oy
        nx = n.x - ox
        box = self.assets.get("node_box")
        if box is not None:
            paste_rgba(canvas, box, (nx, int(ny)))
        if selected:
            draw.rectangle([nx - 3, ny - 3, nx + NODE_W + 2, ny + NODE_H + 2],
                           outline=(255, 255, 255, 255), width=4)

        mat_img = self.assets.get_material(n.material, n.stars)
        if mat_img is not None:
            if getattr(n, "mat_right", False):
                mx = nx + NODE_W - mat_img.width // 2
            else:
                mx = nx - mat_img.width // 2
            my = ny + NODE_H // 2 - mat_img.height // 2
            paste_rgba(canvas, mat_img, (mx, my))
            stars_val = str(star_count(n.stars)) if n.material == "ALL" else (n.stars or "").strip()
            if n.material == "ALL":
                font = load_font(28, True)
                label = (n.stars or "").strip() or "1"
                bb = draw.textbbox((0, 0), label, font=font)
                tw, th = bb[2] - bb[0], bb[3] - bb[1]
                tx = mx + (mat_img.width - tw) / 2
                ty = my + (mat_img.height - th) / 2 - 6
                draw.text((tx, ty), label, font=font, fill=(0, 0, 0, 255))
            elif stars_val:
                star = self.assets.get("Star")
                if star is not None:
                    star_draw = star.resize((STAR_DRAW, STAR_DRAW), Image.Resampling.LANCZOS)
                    sx = mx + mat_img.width - star_draw.width - 1
                    sy = my + 1
                    paste_rgba(canvas, star_draw, (sx, sy))
                    font = load_font(STAR_NUM, True)
                    bb = draw.textbbox((0, 0), stars_val, font=font)
                    tw, th = bb[2] - bb[0], bb[3] - bb[1]
                    draw.text((sx + (star_draw.width - tw) / 2, sy + (star_draw.height - th) / 2 - 1),
                              stars_val, font=font, fill=(20, 20, 20, 255))

        # title centered, moved up 10px
        font = load_font(14, True)
        title = n.title
        bb = draw.textbbox((0, 0), title, font=font)
        tw, th = bb[2] - bb[0], bb[3] - bb[1]
        tx = nx + (NODE_W - tw) / 2
        ty = ny + (NODE_H - th) / 2 - 10
        draw.text((tx, ty), title, font=font, fill=(25, 25, 25, 255))

        # elevator glyph in middle of node
        if n.elevator and n.elevator != "none":
            ev = self.assets.get_elevator(n.elevator)
            if ev is not None:
                half = ev.width / 2
                dx = clamp(int(getattr(n, "elev_dx", 0)),
                           int(-NODE_W / 2 + half), int(NODE_W / 2 - half))
                ex = int(nx + NODE_W / 2 - half + dx)
                ey = int(ny + NODE_H / 2 - ev.height / 2 + 22)
                paste_rgba(canvas, ev, (ex, ey))

        conn = self.assets.get("node_connect")
        for pk, pdata in n.ports.items():
            tgt = (pdata.get("target") or "").strip()
            if not tgt:
                continue
            px, py = port_position(n, pk, fc, min_floor)
            px, py = px - ox, py - oy
            ch = conn.height if conn is not None else CONNECT_H
            cw = conn.width if conn is not None else CONNECT_W
            paste_rgba(canvas, conn, (px, py))

    def export_png(self, state: MapState, path: str,
                   hide_stickers: bool = False, hide_paths: bool = False,
                   flip_bg: bool = False, quality: int = 80):
        img = self.render(state, crop=True, hide_stickers=hide_stickers, hide_paths=hide_paths,
                          flip_bg=flip_bg)
        # footer
        footer_h = 28
        out = Image.new("RGBA", (img.width, img.height + footer_h), (18, 18, 18, 255))
        out.paste(img, (0, 0), img)
        d = ImageDraw.Draw(out)
        font = load_font(14)
        d.text((8, img.height + 6), FOOTER, font=font, fill=(220, 220, 220, 255))
        # flatten
        bg = Image.new("RGB", out.size, (20, 20, 20))
        bg.paste(out, mask=out.split()[-1])
        q = int(quality) if str(quality).strip().lstrip("-").isdigit() else 80
        q = 20 if q < 20 else 100 if q > 100 else q
        out_path = path
        low = out_path.lower()
        if low.endswith(".png"):
            out_path = out_path[:-4] + ".webp"
        elif not low.endswith(".webp"):
            out_path = out_path + ".webp"
        bg.save(out_path, format="WEBP", quality=q)
        return out_path


def enrich_groups(state: MapState, assets: AssetStore) -> dict:
    """Attach sticker/asset names whose bbox sits inside a node perimeter."""
    fc = state.floor_count()
    mf = state.min_floor()
    data = state.to_dict()
    for nd in data["nodes"]:
        node = state.find_by_id(nd["id"])
        ny = node_y_on_floor(node.floor, fc, mf)
        nx1, ny1 = node.x, ny
        nx2, ny2 = node.x + NODE_W, ny + NODE_H
        group = []
        # material / elevator count as grouped images
        if node.material and node.material not in ("Empty", "none"):
            group.append(node.material)
        if node.elevator and node.elevator != "none":
            group.append(f"Elevator_{node.elevator}")
        for st in state.stickers:
            img = assets.get(st.name)
            if img is None:
                continue
            x, y = sticker_world(st)
            w, h = sticker_size(st.name, assets, getattr(st, "big", False))
            cx, cy = x + w / 2, y + h / 2
            if nx1 <= cx <= nx2 and ny1 <= cy <= ny2:
                group.append(st.name)
        nd["group"] = group
    return data


def _norm_folder(val) -> str:
    return str(val or "").replace("\\", "/").replace("//", "/").strip("/")


def catalog_folder_rels(assets: "AssetStore") -> set:
    out = set()
    for ent in getattr(assets, "catalog_entries", None) or []:
        if ent and ent[0] == "cat":
            rel = ent[3] if len(ent) > 3 else ent[1]
            out.add(_norm_folder(rel).lower())
    return out


def snapshot_ui(lock_stickers, hide_mode, show_floor_ruler, flip_bg, starred, collapsed) -> dict:
    cols = []
    for item in collapsed or []:
        if isinstance(item, (list, tuple)) and item:
            cols.append(_norm_folder(item[0]))
        else:
            cols.append(_norm_folder(item))
    return {
        "lock_stickers": bool(lock_stickers),
        "hide_mode": int(hide_mode or 0),
        "floor_ruler": bool(show_floor_ruler),
        "flip_bg": bool(flip_bg),
        "starred_folders": [_norm_folder(x) for x in (starred or [])],
        "collapsed_folders": cols,
    }


def apply_ui_prefs(ui: dict, assets: "AssetStore"):
    ui = ui or {}
    known = catalog_folder_rels(assets)
    starred = []
    for x in ui.get("starred_folders") or []:
        rel = _norm_folder(x)
        if rel.lower() in known:
            starred.append(rel)
    collapsed = set()
    raw_col = ui.get("collapsed_folders") or []
    for item in raw_col:
        if isinstance(item, dict):
            rel = _norm_folder(item.get("folder"))
            depth = int(item.get("depth") or 1)
        elif isinstance(item, (list, tuple)) and item:
            rel = _norm_folder(item[0])
            depth = int(item[1]) if len(item) > 1 else 1
        else:
            rel = _norm_folder(item)
            depth = 1
        if rel.lower() in known:
            collapsed.add((rel, depth))
    hide_mode = int(ui.get("hide_mode") or 0)
    hide_mode = 0 if hide_mode < 0 else 2 if hide_mode > 2 else hide_mode
    return {
        "lock_stickers": bool(ui.get("lock_stickers")),
        "hide_mode": hide_mode,
        "show_floor_ruler": bool(ui.get("floor_ruler")),
        "flip_bg": bool(ui.get("flip_bg")),
        "starred": set(starred),
        "collapsed": collapsed,
    }


# ---------------------------------------------------------------------------
# Collision / drag helpers
# ---------------------------------------------------------------------------

def elevator_on_floor(state: MapState, kind: str, floor: int,
                     ignore_id: Optional[str] = None) -> bool:
    if not kind or kind == "none":
        return False
    return any(o.elevator == kind and o.floor == floor and o.id != ignore_id
               for o in state.nodes)


def rig_members(node: Node, state: MapState) -> List[Node]:
    if node.elevator and node.elevator != "none":
        return state.elevator_segment(node)
    return [node]


def merge_intervals(ivals: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
    if not ivals:
        return []
    ivals = sorted(ivals)
    out = [[ivals[0][0], ivals[0][1]]]
    for a, b in ivals[1:]:
        if a <= out[-1][1] + GRID:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(a, b) for a, b in out]


def occupied_intervals(node: Node, state: MapState,
                       floors: Optional[List[int]] = None,
                       ignore_ids: Optional[set] = None) -> List[Tuple[int, int]]:
    members = rig_members(node, state)
    skip = set(ignore_ids or []) | {m.id for m in members}
    fls = set(floors if floors is not None else [m.floor for m in members])
    ivals = []
    for fl in fls:
        for o in state.nodes_on_floor(fl):
            if o.id in skip:
                continue
            ivals.append((o.x, o.x + NODE_W))
    return merge_intervals(ivals)


def slot_fits(x: int, intervals: List[Tuple[int, int]]) -> bool:
    if x < 0 or x + NODE_W > MAP_W:
        return False
    for a, b in intervals:
        if not (x + NODE_W + GRID <= a or b + GRID <= x):
            return False
    return True



def search_left_then_right(desired_x: int, intervals: List[Tuple[int, int]]) -> Optional[int]:
    """Prefer desired X. If blocked, walk left one tile at a time, then right."""
    x0 = snap(clamp(desired_x, 0, MAP_W - NODE_W))
    if slot_fits(x0, intervals):
        return x0
    x = x0 - GRID
    while x >= 0:
        if slot_fits(x, intervals):
            return x
        x -= GRID
    x = x0 + GRID
    while x + NODE_W <= MAP_W:
        if slot_fits(x, intervals):
            return x
        x += GRID
    return None


def proposed_x_legal(node: Node, new_x: int, state: MapState, direction: int,
                     floor: Optional[int] = None) -> Tuple[int, bool, Optional[str]]:
    """Stop at the 15px gap. Jump only into a gap that fully fits the box
    on every floor of the elevator rig. Never jumps the opposite way."""
    new_x = snap(clamp(new_x, 0, MAP_W - NODE_W))
    extra = [floor] if floor is not None else None
    ivals = occupied_intervals(node, state, floors=extra)

    if direction == 0:
        return (new_x if slot_fits(new_x, ivals) else node.x), False, None
    if slot_fits(new_x, ivals):
        return new_x, False, None

    hits = [iv for iv in ivals if not (new_x + NODE_W + GRID <= iv[0] or iv[1] + GRID <= new_x)]
    if direction > 0:
        hits = [iv for iv in hits if iv[1] > node.x]
        hits.sort(key=lambda t: t[0])
        if not hits:
            return new_x, False, None
        first = hits[0]
        rest_at = snap(first[0] - NODE_W - GRID)
        if rest_at < 0 or not slot_fits(rest_at, [iv for iv in ivals if iv != first]):
            rest_at = node.x
        if new_x < first[0] + NODE_W // 2:
            return max(node.x, rest_at), False, None
        ahead = [iv for iv in ivals if iv[0] >= first[0]]
        for i, (a, b) in enumerate(ahead):
            dest = snap(b + GRID)
            nxt = ahead[i + 1][0] if i + 1 < len(ahead) else MAP_W
            if dest + NODE_W + GRID <= nxt and slot_fits(dest, ivals):
                return dest, True, None
        return rest_at, False, "REFUSED: no gap to the right that fits"

    hits = [iv for iv in hits if iv[0] < node.x + NODE_W]
    hits.sort(key=lambda t: t[0])
    if not hits:
        return new_x, False, None
    last = hits[-1]
    rest_at = snap(last[1] + GRID)
    if rest_at + NODE_W > MAP_W or not slot_fits(rest_at, [iv for iv in ivals if iv != last]):
        rest_at = node.x
    if new_x + NODE_W > last[0] + NODE_W // 2:
        return min(node.x, rest_at), False, None
    behind = [iv for iv in ivals if iv[1] <= last[1]]
    for i, (a, b) in enumerate(reversed(behind)):
        dest = snap(a - NODE_W - GRID)
        prev = behind[len(behind) - 2 - i][1] if i + 1 < len(behind) else 0
        if dest >= prev + GRID and slot_fits(dest, ivals):
            return dest, True, None
    return rest_at, False, "REFUSED: no gap to the left that fits"


def fit_x_on_floor(node: Node, desired_x: int, floor: int, state: MapState) -> Optional[int]:
    """Fit on `floor` at desired X, else left, else right. None = floor full.
    Existing elevator shafts stay on their column or refuse."""
    ivals = occupied_intervals(node, state, floors=[floor], ignore_ids={node.id})
    if node.elevator != "none":
        grp = state.segment_touching_floor(node.elevator, floor, node.id)
        if grp:
            x = grp[0].x
            return x if slot_fits(x, ivals) else None
    return search_left_then_right(desired_x, ivals)


def collect_node_stickers(node: Node, state: MapState, assets: "AssetStore", fc: int):
    mf = state.min_floor()
    ny = node_y_on_floor(node.floor, fc, mf)
    out = []
    for st in state.stickers:
        if sticker_hits_node(st, node, assets, fc, min_floor=mf):
            out.append((st.id, st.tile_x - node.x, st.tile_y - ny))
    return out


def apply_node_stickers(node: Node, offsets, state: MapState, fc: int):
    ny = node_y_on_floor(node.floor, fc, state.min_floor())
    by_id = {s.id: s for s in state.stickers}
    for sid, dxt, dyt in offsets:
        st = by_id.get(sid)
        if st:
            st.tile_x = node.x + dxt
            st.tile_y = ny + dyt


def move_node_to_floor(node: Node, new_floor: int, state: MapState, assets: "AssetStore") -> Optional[str]:
    new_floor = int(new_floor)
    blocked = floor_move_blocked(node, new_floor, state)
    if blocked:
        return blocked
    if elevator_on_floor(state, node.elevator, new_floor, node.id):
        return f"REFUSED: {node.elevator} elevator already on {floor_label(new_floor)}"
    dest = fit_x_on_floor(node, node.x, new_floor, state)
    if dest is None:
        return f"REFUSED: floor full"
    if new_floor == node.floor:
        fc = state.floor_count()
        carried = collect_node_stickers(node, state, assets, fc)
        node.x = dest
        apply_node_stickers(node, carried, state, fc)
        return None
    old_fc = state.floor_count()
    offsets = collect_node_stickers(node, state, assets, old_fc)
    node.x = dest
    node.floor = new_floor
    adjust_stickers_after_floor_change(state, assets, old_fc, skip_ids=[o[0] for o in offsets])
    apply_node_stickers(node, offsets, state, state.floor_count())
    if node.elevator != "none":
        apply_elevator_x(state, node.elevator, node.x, assets, anchor=node)
    return None


def resolve_imported_layout(state: MapState) -> None:
    """On JSON import: nudge any overlapping node left, then right."""
    for n in list(state.nodes):
        ivals = occupied_intervals(n, state, floors=[n.floor], ignore_ids={n.id})
        if slot_fits(n.x, ivals):
            continue
        dest = search_left_then_right(n.x, ivals)
        if dest is not None:
            n.x = dest


def spawn_x_for_floor(state: MapState, floor: int, elevator: str = "none") -> Optional[int]:
    dummy = Node(id="__spawn__", title="", floor=floor, x=0, elevator=elevator)
    prefer = blue_elevator_x() if elevator == "blue" else snap((MAP_W - NODE_W) // 2)
    return fit_x_on_floor(dummy, prefer, floor, state)


def apply_elevator_x(state: MapState, kind: str, x: int, assets: Optional["AssetStore"] = None,
                     anchor: Optional[Node] = None):
    if not kind or kind == "none":
        return
    fc = state.floor_count()
    members = state.elevator_segment(anchor) if anchor is not None else state.elevator_group(kind)
    for n in members:
        carried = collect_node_stickers(n, state, assets, fc) if assets is not None else []
        n.x = x
        if assets is not None:
            apply_node_stickers(n, carried, state, fc)


def image_name_variants(name: str):
    """webp first, then png, then the name as given."""
    if not name:
        return []
    root, ext = os.path.splitext(name)
    ext = ext.lower()
    if ext in (".webp", ".png"):
        ordered = [root + ".webp", root + ".png"]
    else:
        ordered = [name + ".webp", name + ".png", name]
    out = []
    for item in ordered:
        if item not in out:
            out.append(item)
    if name not in out:
        out.append(name)
    return out


def find_ui_asset(*names: str) -> str:
    roots = []
    for root in (UI_ASSETS_DIR, UI_ASSETS_BUNDLE, SCRIPT_DIR, bundle_dir()):
        if root and root not in roots:
            roots.append(root)
    for root in roots:
        for name in names:
            for variant in image_name_variants(name):
                path = os.path.join(root, variant)
                if os.path.isfile(path):
                    return path
    return ""


def color_titlebar_black() -> None:
    """Windows: black caption bar, light title text via immersive dark mode."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        import pygame
        wm = pygame.display.get_wm_info()
        hwnd = wm.get("window")
        if not hwnd:
            return
        color = ctypes.c_int(0)
        dark = ctypes.c_int(1)
        dwm = ctypes.windll.dwmapi
        dwm.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(dark), 4)
        dwm.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(color), 4)
        dwm.DwmSetWindowAttribute(hwnd, 34, ctypes.byref(color), 4)
    except Exception:
        pass


def set_windows_app_id() -> None:
    """Stop the taskbar grouping this window under python.exe."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Grimfuldev.LetItDie.NodeMaker")
    except Exception:
        pass


def apply_editor_chrome(screen) -> None:
    import pygame
    set_windows_app_id()
    icon_path = find_ui_asset(ASSET_ICON)
    if icon_path:
        try:
            icon = pygame.image.load(icon_path).convert_alpha()
            pygame.display.set_icon(icon)
        except Exception:
            pass
    if sys.platform == "win32":
        try:
            import ctypes
            hwnd = pygame.display.get_wm_info().get("window")
            if hwnd:
                user32 = ctypes.windll.user32
                shell32 = ctypes.windll.shell32
                exe = sys.executable if getattr(sys, "frozen", False) else ""
                hbig = shell32.ExtractIconW(0, exe, 0) if exe else 0
                if not hbig:
                    ico = find_ui_asset("lidico.ico")
                    if ico:
                        hbig = user32.LoadImageW(None, ico, 1, 0, 0, 0x0010)
                if hbig:
                    user32.SendMessageW(hwnd, 0x0080, 1, hbig)
        except Exception:
            pass
    color_titlebar_black()
    cur_path = find_ui_asset(ASSET_CURSOR)
    if cur_path:
        try:
            cur = pygame.image.load(cur_path).convert_alpha()
            cur = pygame.transform.smoothscale(cur, (32, 32))
            pygame.mouse.set_cursor((0, 0), cur)
        except Exception:
            try:
                pygame.mouse.set_cursor(pygame.cursors.Cursor((0, 0), cur))
            except Exception:
                pass


def load_panel_background(width: int, height: int):
    import pygame
    path = find_ui_asset(ASSET_BG)
    if not path or width < 8 or height < 8:
        return None
    try:
        img = pygame.image.load(path).convert()
        return pygame.transform.smoothscale(img, (width, height))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Minimal pygame UI toolkit
# ---------------------------------------------------------------------------